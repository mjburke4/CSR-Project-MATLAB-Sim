#pragma once
#include "csr-common.h"
#include "csr-mac-core.h"
#include "csr-opnet-envelope.h"
#include "csr-phy-model.h"

#include <limits>
#include <optional>

#include "ns3/trace-source-accessor.h"
#include "ns3/traced-callback.h"

class CsrNetDevice : public Object
{
public:
  /** Trace callback for one source-style synchronization decision. */
  typedef void (*SyncDecisionTracedCallback) (CsrNodeId transmitter,
                                               uint16_t sequence,
                                               double snrDb,
                                               double thresholdDb,
                                               bool accepted);

  CsrNetDevice ()
    : CsrNetDevice (0)
  {
  }

  CsrNetDevice (CsrNodeId id)
    : m_id (id),
      m_rng (CreateObject<UniformRandomVariable> ()),
      m_syncThresholdRng (CreateObject<NormalRandomVariable> ())
  {
    NS_ABORT_MSG_IF (!CsrIsValidNodeId (id),
                     "CSR device node identifier exceeds 24 bits");
    m_mac.SetNodeId (id);
    m_mac.SetDevice (this);
  }

  static TypeId GetTypeId (void)
  {
    static TypeId tid = TypeId ("ns3::CsrNetDevice")
      .SetParent<Object> ()
      .AddConstructor<CsrNetDevice> ()
      .AddTraceSource (
        "SyncDecision",
        "A channel-matched SYNC attempt with its SNR, sampled threshold, "
        "and acceptance decision.",
        MakeTraceSourceAccessor (&CsrNetDevice::m_syncDecisionTrace),
        "ns3::CsrNetDevice::SyncDecisionTracedCallback");
    return tid;
  }

  /**
   * Assign deterministic streams to device-owned random variables.
   *
   * The first stream controls the existing device-uniform draws (PHY error
   * realization and compatibility duty-cycle phase) and the second controls
   * source-style synchronization thresholds.
   *
   * @param stream First stream index.
   * @return Number of streams assigned.
   */
  int64_t AssignStreams (int64_t stream)
  {
    m_rng->SetStream (stream);
    m_syncThresholdRng->SetStream (stream + 1);
    return 2;
  }

  /**
   * Force a deterministic synchronization threshold for controlled tests.
   *
   * This is an explicit compatibility/testing override. Source-exact runs
   * leave it clear and sample the configured normal distribution.
   *
   * @param thresholdDb Threshold in dB.
   */
  void SetSyncSnrThresholdOverrideDb (double thresholdDb)
  {
    NS_ABORT_MSG_IF (!std::isfinite (thresholdDb),
                     "CSR SYNC threshold override must be finite");
    m_syncThresholdOverrideDb = thresholdDb;
  }

  /** Clear the deterministic synchronization-threshold override. */
  void ClearSyncSnrThresholdOverride ()
  {
    m_syncThresholdOverrideDb.reset ();
  }

  void SetPeer (Ptr<CsrNetDevice> peer)
  {
    // backward-compatible: single peer
    m_peers.clear ();
    if (peer != nullptr)
      {
        m_peers.push_back (peer);
      }
  }

  void AddPeer (Ptr<CsrNetDevice> peer)
  {
    if (peer != nullptr)
      {
        m_peers.push_back (peer);
      }
  }

  void EnableDutyCycling (bool enable)
  {
    m_opnetAlignedDutyCycle = false;
    if (m_opnetPeriodicWakeEvent.IsPending ())
      {
        Simulator::Cancel (m_opnetPeriodicWakeEvent);
      }
    m_dutyCycleEnabled = enable;
    if (!enable && m_pendingTxWakeEvent.IsPending ())
      {
        Simulator::Cancel (m_pendingTxWakeEvent);
      }
    if (enable && m_rng)
      {
        // De-sync nodes so they don't all wake at same instant
        m_wakePhaseSec = m_rng->GetValue (0.0, m_wakeCycleSec);
      }
    RefreshDutyState ();
    if (enable &&
        m_mac.GetState () == CsrMacCore::State::IDLE &&
        m_mac.HasPendingFrames ())
      {
        SchedulePendingTxWake ();
      }
  }

  /**
   * Enable the source-aligned OPNET wake lifecycle.
   *
   * Unlike EnableDutyCycling(), this mode does not draw a random phase.  The
   * receiver begins in Idle and its first unconditional WAKE occurs at
   * WAKE_CYCLE (0.988 s), matching br_mac_init() in br_mac.pr.c.
   */
  void EnableOpnetAlignedDutyCycling (bool enable)
  {
    m_opnetAlignedDutyCycle = enable;
    m_dutyCycleEnabled = enable;
    m_wakePhaseSec = 0.0;

    if (m_opnetPeriodicWakeEvent.IsPending ())
      {
        Simulator::Cancel (m_opnetPeriodicWakeEvent);
      }
    if (m_signalWakeEvent.IsPending ())
      {
        Simulator::Cancel (m_signalWakeEvent);
      }
    if (m_pendingTxWakeEvent.IsPending ())
      {
        Simulator::Cancel (m_pendingTxWakeEvent);
      }

    RefreshDutyState ();
    if (enable)
      {
        ScheduleOpnetPeriodicWake ();
      }
  }

  bool IsDutyCyclingEnabled () const { return m_dutyCycleEnabled; }

  /** Set a deterministic wake phase, primarily for repeatable scenarios. */
  void SetDutyCyclePhase (Time phase)
  {
    m_opnetAlignedDutyCycle = false;
    if (m_opnetPeriodicWakeEvent.IsPending ())
      {
        Simulator::Cancel (m_opnetPeriodicWakeEvent);
      }
    double seconds = std::fmod (phase.GetSeconds (), m_wakeCycleSec);
    m_wakePhaseSec = seconds < 0.0 ? seconds + m_wakeCycleSec : seconds;
    if (m_pendingTxWakeEvent.IsPending ())
      {
        Simulator::Cancel (m_pendingTxWakeEvent);
      }
    RefreshDutyState ();
    if (m_dutyCycleEnabled &&
        m_mac.GetState () == CsrMacCore::State::IDLE &&
        m_mac.HasPendingFrames ())
      {
        SchedulePendingTxWake ();
      }
  }

  void ForceAwakeFor (double seconds)
  {
    double now = Simulator::Now ().GetSeconds ();
    m_forceAwakeUntilSec = std::max (m_forceAwakeUntilSec, now + seconds);
    if (m_mac.GetState () == CsrMacCore::State::IDLE)
      {
        m_mac.SetReceiveState (CsrMacCore::State::SEARCH);
      }

    if (m_forceAwakeEndEvent.IsPending ())
      {
        Simulator::Cancel (m_forceAwakeEndEvent);
      }
    m_forceAwakeEndEvent = Simulator::Schedule (
      Seconds (std::max (0.0, m_forceAwakeUntilSec - now)),
      &CsrNetDevice::RefreshDutyState,
      this);
  }

  CsrMacCore& GetMac ()
  {
    return m_mac;
  }

  /**
   * Configure the MAC-only rate profile for direct device scenarios.
   *
   * Full NWK/HOP stacks should set the profile on CsrNetLayer so it propagates
   * consistently through link control and MAC selection.
   *
   * @param profile Runtime payload-rate profile.
   */
  void SetRateProfile (CsrRateProfile profile)
  {
    m_mac.SetRateProfile (profile);
  }

  /** @return Active MAC-only payload-rate profile. */
  CsrRateProfile GetRateProfile () const
  {
    return m_mac.GetRateProfile ();
  }

  CsrPhyModel& GetPhy() { return m_phy; }

  CsrNodeId GetId () const { return m_id; }

  /** Return the current OPNET Idle/Search/Track/Tx state. */
  CsrMacCore::State GetMacState () const
  {
    return m_mac.GetState ();
  }

  /** Return the number of overlapping acceptable preambles observed. */
  uint64_t GetRxCollisionCount () const
  {
    return m_rxCollisionCount;
  }

  /** Return the number of tracked frames that captured weaker interference. */
  uint64_t GetRxCaptureCount () const
  {
    return m_rxCaptureCount;
  }

  /** Return the number of frames missed while asleep or transmitting. */
  uint64_t GetRxMissCount () const
  {
    return m_rxMissCount;
  }

  /** Return the number of packets rejected specifically by br_ecc. */
  uint64_t GetRxEccDropCount () const
  {
    return m_rxEccDropCount;
  }

  /** Return whether a tracked signal has completed a PHY decision. */
  bool HasLastRxDecision () const
  {
    return m_hasLastRxDecision;
  }

  /** Return whether source post-Tx WAIT_FOR_ACK currently owns Search. */
  bool IsPostTxWaitActive () const
  {
    return m_postTxWaitActive;
  }

  /** Return the most recent tracked receive decision and PHY diagnostics. */
  const CsrRxDecision &GetLastRxDecision () const
  {
    NS_ABORT_MSG_IF (!m_hasLastRxDecision,
                     "CSR receiver has no completed PHY decision");
    return m_lastRxDecision;
  }

  /** Configure the source-backed JSR boundary used before PHY calibration. */
  void SetCaptureMarginDb (double marginDb)
  {
    m_captureMarginDb = marginDb;
  }

  void SetActiveNodesForPostTx (uint32_t n)
  {
    m_activeNodesForPostTx = std::max<uint32_t> (1, n);
  }

  void NoteReportedActiveNodes (uint32_t n)
  {
    if (n > m_maxReportedActiveNodes)
      {
        m_maxReportedActiveNodes = n;

        std::cout << "[MAC " << m_id
                  << "] max_reported_active_nodes updated to "
                  << m_maxReportedActiveNodes
                  << std::endl;
      }
  }

  uint32_t GetReportedActiveNodesForSlotting () const
  {
    return std::max<uint32_t> (m_activeNodesForPostTx,
                              m_maxReportedActiveNodes);
  }

  Time SendToPeer (Ptr<Packet> frame,
                   CsrNodeId dest,
                   int rateKbps,
                   double txPowerDbm,
                   PreambleType preamble,
                   int slot,
                   bool ackable);

  Time SendFramesToPeers (const std::vector<Ptr<Packet>> &frames,
                          int rateKbps,
                          double txPowerDbm,
                          PreambleType preamble,
                          int slot,
                          bool ackable);

private:
  friend class CsrMacCore;
  friend struct CsrPhyFrontEndSmokeAccess;

  struct RxSignal
  {
    uint64_t id {0};
    uint64_t arrivalOrder {0};
    CsrNodeId txId {0};
    uint16_t sequence {0};
    std::vector<Ptr<Packet>> frames;
    int rateKbps {8};
    double txPowerDbm {0.0};
    PreambleType preamble {PREAMBLE_LONG};
    int reservedSlot {-1};
    bool ackable {false};
    uint32_t payloadBytes {0};
    uint32_t packetBits {0};
    CsrTxRadioProfile txRadio;
    CsrPhyFrontEndResult frontEnd;
    double startSec {0.0};
    double endSec {0.0};
    double preambleEndSec {0.0};
    double pathlossDb {0.0};
    double rxPowerDbm {0.0};
    double snrDb {0.0};
    double currentInterferenceWatts {0.0};
    std::map<uint64_t, double> additiveInterferenceWatts; ///< Noise contribution by signal ID.
    double peakNoiseWatts {0.0};
    double intervalStartSec {0.0};
    double jsrDb {-std::numeric_limits<double>::infinity ()};
    double timeOffsetSeconds {0.0};
    uint32_t collisionCount {0};
    std::vector<CsrBerInterval> berIntervals;
    CsrErrorAllocation errorAllocation;
    bool syncEligible {false};
    bool sameRateInterference {false};
    bool preambleActive {true};
    bool rejected {false};
    bool rejectedDuringTrack {false};
    bool tracked {false};
    bool collided {false};
    bool missedByState {false};
  };

  void BeginReceiveSignal (RxSignal signal);
  double DrawSyncSnrThresholdDb ();
  void EndReceivePreamble (uint64_t signalId);
  void EndReceiveSignal (uint64_t signalId);
  void AcquireSignal ();
  void ScheduleAcquisition ();
  void ReturnToSearchAfterReceive ();
  void ReturnRejectedReceiveToSearch ();
  void ApplyTrackedInterference (RxSignal &interferer);
  void ApplyInterferencePair (RxSignal &first, RxSignal &second);
  void RemoveEndedInterference (const RxSignal &ended);
  void UpdateSignalNoise (RxSignal &signal);
  void CloseSignalInterval (RxSignal &signal, double endSec);
  void CloseAllSignalIntervals (double endSec);
  void StartAllSignalIntervals (double startSec);
  void RecordSameRateInterference (RxSignal &desired,
                                   const RxSignal &jammer);
  void RefreshHighRateInterference ();
  void DeliverTrackedSignal (const RxSignal &signal,
                             const CsrRxDecision &decision);
  void UpdateSyncPresence ();
  void RefreshDutyState ();
  void WakeForSignal ();
  void WakeForPendingTx ();
  void OpnetPeriodicWake ();
  void SleepReceiver ();
  void ScheduleSignalWake ();
  void SchedulePendingTxWake ();
  void ScheduleOpnetPeriodicWake ();
  void StartPostTxWait ();
  void CancelPostTxWait ();
  void PostTxWaitExpired ();
  bool IsPeriodicAwakeAt (double timeSec) const;
  double GetPeriodicWindowEnd (double timeSec) const;
  double GetNextPeriodicWake (double timeSec) const;
  void OnMacTxFinished (bool queuesEmpty);

  CsrNodeId                       m_id {0};
  CsrMacCore                     m_mac;
  std::vector< Ptr<CsrNetDevice> > m_peers;   // multiple peers on shared channel
  Ptr<UniformRandomVariable>     m_rng;
  Ptr<NormalRandomVariable>      m_syncThresholdRng;
  CsrPhyModel                    m_phy;
  std::map<uint64_t, RxSignal>   m_rxSignals;
  uint64_t                       m_nextTxSignalId {0};
  uint64_t                       m_nextRxArrivalOrder {0};
  uint64_t                       m_trackedSignalId {0};
  uint64_t                       m_rxCollisionCount {0};
  uint64_t                       m_rxCaptureCount {0};
  uint64_t                       m_rxMissCount {0};
  uint64_t                       m_rxEccDropCount {0};
  bool                           m_hasLastRxDecision {false};
  CsrRxDecision                  m_lastRxDecision;
  std::optional<double>          m_syncThresholdOverrideDb;
  TracedCallback<CsrNodeId,
                 uint16_t,
                 double,
                 double,
                 bool>           m_syncDecisionTrace;
  EventId                        m_acquisitionEvent;
  EventId                        m_signalWakeEvent;
  EventId                        m_pendingTxWakeEvent;
  EventId                        m_opnetPeriodicWakeEvent;
  EventId                        m_sleepEvent;
  EventId                        m_forceAwakeEndEvent;
  EventId                        m_postTxWaitEvent;
  EventId                        m_doneRxEvent;

  // --- Duty cycling (OPNET-inspired) ---
  bool   m_dutyCycleEnabled { false };
  bool   m_opnetAlignedDutyCycle { false };

  // OPNET constants:
  //   WAKE_CYCLE ~0.988 s
  //   DSP_RX_BOOTTIME 0.0011 s
  //   NO_SIG_SRH_TIME 0.0078 s
  double m_wakeCycleSec     { 0.988 };
  double m_awakeWindowSec   { 0.0011 + 0.0078 }; // ~0.0089 s
  double m_noSignalSearchSec { 0.0078 };
  double m_wakePhaseSec     { 0.0 };             // randomized per node
  double m_forceAwakeUntilSec { 0.0 };
  bool m_postTxWaitActive {false};
  double m_syncToTrackSec { 0.00663 };
  // Retained for explicit compatibility BER hooks.  The production path uses
  // the source-derived JSR buckets, BER tables, interval errors, and ECC gate.
  double m_captureMarginDb {10.5};
  bool m_rxSameSpeed {false};
  double m_rxJsrDb {-1000.0};
  double m_rxTimeOffsetSeconds {0.0};
  // OPNET br_mac.pr.c:
  // POST_TX_WAIT_TIME = STAY_AWAKE_BASE_TIME + 1.5*active_nodes + STAY_AWAKE_GUARD_TIME
  double m_stayAwakeBaseSec  { 15.0 };
  double m_stayAwakeGuardSec { 0.5 };

  // Placeholder until active_nodes is plumbed from NWK/MAC state.
  // br_mac initializes active_nodes to 1.
  uint32_t m_activeNodesForPostTx { 1 };

  uint32_t m_maxReportedActiveNodes {0};


  /*void NoteReportedActiveNodes (uint32_t n)
  {
    if (n > m_maxReportedActiveNodes)
      {
        m_maxReportedActiveNodes = n;
      }
  }*/

  double GetPostTxWaitSeconds () const
  {
    return m_stayAwakeBaseSec
        + 1.5 * static_cast<double> (m_activeNodesForPostTx)
        + m_stayAwakeGuardSec;
  }

};

// Keep MAC-local active_nodes and device post-TX active_nodes synchronized.
// MAC uses this for OPNET get_slot() range;
// CsrNetDevice uses this for POST_TX_WAIT_TIME.
/*void
CsrMacCore::SetActiveNodesForPostTx (uint32_t n)
{
  uint32_t active = std::max<uint32_t> (1, n);

  // MAC-local reported active-node state used by PickTxSlot()
  NoteReportedActiveNodes (active);

  // Device copy used by POST_TX_WAIT_TIME
  if (m_dev != nullptr)
    {
      m_dev->SetActiveNodesForPostTx (active);
    }

  std::cout << "[MAC " << m_nodeId
            << "] active_nodes set to "
            << active
            << " for slotting and post-TX wait"
            << std::endl;
}*/

void
CsrMacCore::SetActiveNodesForPostTx (uint32_t n)
{
  uint32_t active = std::max<uint32_t> (1, n);

  // Local active_nodes used by MAC slotting.
  // Keep separate from max_reported_active_nodes.
  m_activeNodesForPostTx = active;

  // Device copy used by OPNET-style POST_TX_WAIT_TIME.
  if (m_dev != nullptr)
    {
      m_dev->SetActiveNodesForPostTx (active);
    }

  std::cout << "[MAC " << m_nodeId
            << "] active_nodes set to "
            << active
            << " for local slotting and post-TX wait"
            << std::endl;
}

void
CsrMacCore::PrintNeighbors () const
{
  double now = Simulator::Now ().GetSeconds ();
  std::cout << "[NEIGH " << m_dev->GetId () << " t=" << now << "] ";

  if (m_lastHeardSec.empty ())
    {
      std::cout << "(none)" << std::endl;
      return;
    }

  bool first = true;
  for (auto const& kv : m_lastHeardSec)
    {
      CsrNodeId n = kv.first;
      double age = now - kv.second;

      if (!first) std::cout << " | ";
      first = false;

      std::cout << "n=" << n << " age=" << age << "s";

      auto itPl = m_lastPathlossDb.find (n);
      if (itPl != m_lastPathlossDb.end ())
        std::cout << " pl=" << itPl->second << "dB";
    }
  std::cout << std::endl;
}

void
CsrMacCore::SendHelloInternal (bool reschedule)
{
  // Allow HELLO if either periodic is enabled OR discovery is active
  if ((m_dev == nullptr) || (!m_helloEnabled && !m_discoveryActive))
    {
      return;
    }

  CsrHeader h;
  h.SetSrc (m_dev->GetId ());
  h.SetDst (CSR_BROADCAST_ID);
  h.SetSeq (++m_helloSeq);
  h.SetDscp (7);
  h.SetAckable (false);
  h.SetIsAck (false);
  h.SetIsDack (false);

  h.SetType (CSR_PKT_HELLO);
  h.SetDestType (CSR_DEST_BROADCAST);
  h.SetSpeedKey (8);

  Ptr<Packet> p = Create<Packet> ();
  p->AddHeader (h);

  EnqueueTxFrame (p, CSR_BROADCAST_ID, /*dscp*/ 7, /*ackable*/ false);

  // Re-arm only if we're in periodic mode AND caller requested re-arm
  if (reschedule && m_helloEnabled)
    {
      m_helloEvent = Simulator::Schedule (m_helloInterval, &CsrMacCore::SendHello, this);
    }
}

int
CsrMacCore::SelectRateByPerTarget (CsrNodeId destId, uint32_t nBits, double targetPer) const
{
  static const std::vector<int> kRates = {
    8,
    16,
    32,
    64,
    128,
    500,
    1000
  };

  // Access PHY through the owning device (now safe because this definition is after CsrNetDevice is complete)
  const CsrPhyModel& phy = m_dev->GetPhy ();
  CsrNodeId txId = m_dev->GetId ();

  double snrDb = phy.PredictSnrDb (txId, destId, phy.profile.txPowerDbm);

  int chosen = kRates.front (); // most robust default
  for (int r : kRates)
    {
      if (r > m_maxRateKbps)
        {
          break;
        }
      double per = phy.EstimatePer (r, snrDb, nBits);
      if (per <= targetPer)
        chosen = r;
    }

  return chosen;
}

Time
CsrNetDevice::SendToPeer (Ptr<Packet> frame,
                          CsrNodeId dest,
                          int rateKbps,
                          double txPowerDbm,
                          PreambleType preamble,
                          int slot,
                          bool ackable)
{
  std::vector<Ptr<Packet>> frames;
  frames.push_back (frame);
  return SendFramesToPeers (frames,
                            rateKbps,
                            txPowerDbm,
                            preamble,
                            slot,
                            ackable);
}

Time
CsrNetDevice::SendFramesToPeers (
  const std::vector<Ptr<Packet>> &frames,
  int rateKbps,
  double txPowerDbm,
  PreambleType preamble,
  int slot,
  bool ackable)
{
  NS_ASSERT_MSG (!frames.empty (), "cannot transmit an empty CSR aggregate");
  NS_ABORT_MSG_IF (rateKbps < 0 ||
                   static_cast<uint64_t> (rateKbps) >
                     std::numeric_limits<CsrRateKey>::max () ||
                   !CsrIsOperationalRateKey (
                   static_cast<CsrRateKey> (rateKbps)),
                   "CSR transmission rate has no defined airtime or BER model");
  NS_ABORT_MSG_IF (!m_mac.IsRateEnabled (
                     static_cast<CsrRateKey> (rateKbps)),
                   "CSR transmission rate exceeds the active profile ceiling");

  uint32_t payloadBytes = 0;
  std::vector<Ptr<Packet>> frameCopies;
  frameCopies.reserve (frames.size ());
  for (const auto &segment : frames)
    {
      payloadBytes += CsrGetOpnetWireSize (segment);
      frameCopies.push_back (segment->Copy ());
    }

  // br_txdel.ps.c sends the preamble, SOF, speed, and length at S0, then
  // sends the inherited payload and 32-bit FCS at the selected payload rate.
  static constexpr double s0DurationSec = 0.00051;
  uint32_t preambleBits = preamble == PREAMBLE_LONG ? 7888 : 104;
  uint32_t s0HeaderBits = preambleBits + 16 + 16 + 16;
  uint32_t payloadAndFcsBits = payloadBytes * 8 + 32;
  uint32_t packetBits = s0HeaderBits + payloadAndFcsBits;
  double rbps = CsrRateKeyToBps (rateKbps);
  double preambleSec = preambleBits / 4.0 * s0DurationSec;
  double duration = s0HeaderBits / 4.0 * s0DurationSec
                  + payloadAndFcsBits / rbps;

  double txTime = Simulator::Now ().GetSeconds ();

  // For log: peek header
  CsrHeader hdr;
  frameCopies.front ()->PeekHeader (hdr);

  std::cout   << "... type=" << unsigned(hdr.GetType())
              << " speedKey=" << unsigned(hdr.GetSpeedKey())
              << "[t=" << txTime << "] TX from node " << m_id
              << " to dest " << hdr.GetDst ()
              << " seq " << hdr.GetSeq ()
              << " size " << payloadBytes << " bytes"
              << " segments " << frameCopies.size ()
              << " at slot " << slot
              << " rate " << rateKbps << " kbps"
              << " txPower " << txPowerDbm << " dBm"
              << " (" << rbps << " bps)"
              << " preamble " << (preamble == PREAMBLE_LONG ? "LONG" : "SHORT")
              << " duration " << duration << " s"
              << std::endl;

  // Peek header once to know src/dst/seq
  CsrHeader hdrOnTx;
  frameCopies.front ()->PeekHeader (hdrOnTx);
  CsrNodeId txId = hdrOnTx.GetSrc ();
  uint16_t sequence = hdrOnTx.GetSeq ();
  uint64_t signalId = (static_cast<uint64_t> (m_id) << 32)
                    | (++m_nextTxSignalId & 0xffffffffULL);
  Tranche8ObserveFeedbackTransmission (frameCopies, rateKbps, txPowerDbm, signalId);

  CsrDifferentialTraceEvent txEvent;
  txEvent.event = "tx_start";
  txEvent.node = CsrTraceInteger (m_id);
  txEvent.peer = CsrTraceInteger (hdrOnTx.GetDst ());
  txEvent.packetType = CsrPacketTypeName (hdrOnTx.GetType ());
  txEvent.source = CsrTraceInteger (hdrOnTx.GetSrc ());
  txEvent.destination = CsrTraceInteger (hdrOnTx.GetDst ());
  txEvent.sequence = CsrTraceInteger (sequence);
  txEvent.rateKbps = CsrTraceSignedInteger (rateKbps);
  txEvent.sizeBytes = CsrTraceInteger (payloadBytes);
  txEvent.reservationSlot = CsrTraceSignedInteger (slot);
  txEvent.reservationCounter = CsrTraceSignedInteger (slot);
  if (hdrOnTx.HasSecurityCount ())
    {
      txEvent.securityCount = CsrTraceInteger (
        hdrOnTx.GetSecurityCount ());
    }
  txEvent.detail = preamble == PREAMBLE_LONG ? "long" : "short";
  WriteDifferentialTrace (txEvent);

  // A direct SendToPeer call and a queued MAC transmission both occupy the
  // local half-duplex radio for the complete OTA duration.
  m_mac.NotifyPhyTxStart (Seconds (duration));

  for (const auto &peer : m_peers)
    {
      if (peer == nullptr || peer->GetId () == txId)
        {
          continue;
        }

      double distanceMeters = peer->m_phy.GetDistanceMeters (
        txId,
        peer->GetId ());
      CsrTxRadioProfile txRadio = m_phy.GetTxRadioProfile ();
      if (!peer->m_phy.HasClosure (distanceMeters, txRadio))
        {
          std::cout << "[t=" << txTime << "] RX OCCLUDED at node "
                    << peer->GetId () << " from node " << txId
                    << " seq " << sequence
                    << std::endl;
          CsrDifferentialTraceEvent dropEvent;
          dropEvent.event = "rx_drop";
          dropEvent.node = CsrTraceInteger (peer->GetId ());
          dropEvent.peer = CsrTraceInteger (txId);
          dropEvent.packetType = CsrPacketTypeName (hdrOnTx.GetType ());
          dropEvent.source = CsrTraceInteger (hdrOnTx.GetSrc ());
          dropEvent.destination = CsrTraceInteger (hdrOnTx.GetDst ());
          dropEvent.sequence = CsrTraceInteger (sequence);
          dropEvent.rateKbps = CsrTraceSignedInteger (rateKbps);
          dropEvent.sizeBytes = CsrTraceInteger (payloadBytes);
          dropEvent.success = "0";
          dropEvent.reason = "closure";
          dropEvent.detail = "distance_m=" + CsrTraceDouble (distanceMeters);
          WriteDifferentialTrace (dropEvent);
          continue;
        }
      double propagationDelaySec = distanceMeters /
        CsrPhyModel::SPEED_OF_LIGHT_METERS_PER_SECOND;

      RxSignal signal;
      signal.id = signalId;
      signal.txId = txId;
      signal.sequence = sequence;
      signal.rateKbps = rateKbps;
      signal.txPowerDbm = txPowerDbm;
      signal.preamble = preamble;
      signal.reservedSlot = slot;
      signal.ackable = ackable;
      signal.payloadBytes = payloadBytes;
      signal.packetBits = packetBits;
      signal.txRadio = txRadio;
      signal.startSec = txTime + propagationDelaySec;
      signal.endSec = signal.startSec + duration;
      signal.preambleEndSec = signal.startSec + preambleSec;
      signal.frames.reserve (frameCopies.size ());
      for (const auto &segment : frameCopies)
        {
          signal.frames.push_back (segment->Copy ());
        }

      Simulator::Schedule (Seconds (propagationDelaySec), [peer, signal] () {
        peer->BeginReceiveSignal (signal);
      });
    }

  return Seconds (duration);
}

bool
CsrNetDevice::IsPeriodicAwakeAt (double timeSec) const
{
  if (m_opnetAlignedDutyCycle && timeSec < m_wakeCycleSec)
    {
      return false;
    }

  double offset = std::fmod (timeSec - m_wakePhaseSec, m_wakeCycleSec);
  if (offset < 0.0)
    {
      offset += m_wakeCycleSec;
    }
  return offset < m_awakeWindowSec;
}

double
CsrNetDevice::GetPeriodicWindowEnd (double timeSec) const
{
  double offset = std::fmod (timeSec - m_wakePhaseSec, m_wakeCycleSec);
  if (offset < 0.0)
    {
      offset += m_wakeCycleSec;
    }
  return IsPeriodicAwakeAt (timeSec)
    ? timeSec + m_awakeWindowSec - offset
    : timeSec;
}

double
CsrNetDevice::GetNextPeriodicWake (double timeSec) const
{
  if (m_opnetAlignedDutyCycle && timeSec < m_wakeCycleSec)
    {
      return m_wakeCycleSec;
    }

  double offset = std::fmod (timeSec - m_wakePhaseSec, m_wakeCycleSec);
  if (offset < 0.0)
    {
      offset += m_wakeCycleSec;
    }
  if (offset < m_awakeWindowSec)
    {
      return timeSec;
    }
  return timeSec + m_wakeCycleSec - offset;
}

void
CsrNetDevice::RefreshDutyState ()
{
  CsrMacCore::State state = m_mac.GetState ();
  if (state == CsrMacCore::State::TRACK ||
      state == CsrMacCore::State::TX)
    {
      return;
    }

  if (!m_dutyCycleEnabled)
    {
      m_mac.SetReceiveState (CsrMacCore::State::SEARCH);
      return;
    }

  double now = Simulator::Now ().GetSeconds ();
  // A queued frame alone does not extend a wake-only Search: the source's
  // 8.9-ms no-signal sleep can precede its 13-ms TSLOT.  Once Idle RTS or a
  // Search TSLOT has enabled PREP_TX, that preparation keeps Search active.
  bool preparationKeepsSearch =
    state == CsrMacCore::State::SEARCH &&
    m_mac.IsTxPreparationActive ();
  // A pending SLEEP interrupt is the source-owned no-signal Search window.
  // Keep that state through its exact deadline so a new SYNC can acquire and
  // cancel the event on entry to Track.
  bool noSignalSearchActive =
    state == CsrMacCore::State::SEARCH &&
    m_sleepEvent.IsPending ();
  bool shouldSearch = preparationKeepsSearch ||
                      noSignalSearchActive ||
                      m_postTxWaitActive ||
                      m_forceAwakeUntilSec > now ||
                      IsPeriodicAwakeAt (now);
  m_mac.SetReceiveState (shouldSearch
                           ? CsrMacCore::State::SEARCH
                           : CsrMacCore::State::IDLE);
}

void
CsrNetDevice::SleepReceiver ()
{
  CsrMacCore::State state = m_mac.GetState ();
  if (state == CsrMacCore::State::TRACK ||
      state == CsrMacCore::State::TX)
    {
      return;
    }
  if (!m_dutyCycleEnabled)
    {
      return;
    }

  // This callback is the source model's already-scheduled SLEEP interrupt,
  // not a fresh query of the periodic wake phase.  Recomputing the phase with
  // floating-point fmod() exactly at the awake-window boundary can classify
  // the boundary as still awake and lose this one-shot Search -> Idle
  // transition.  br_mac instead runs dsp_off() when SLEEP is delivered unless
  // transmit preparation or a separate stay-awake guard has superseded it.
  double now = Simulator::Now ().GetSeconds ();
  bool preparationKeepsSearch =
    state == CsrMacCore::State::SEARCH &&
    m_mac.IsTxPreparationActive ();
  if (preparationKeepsSearch ||
      m_postTxWaitActive ||
      m_forceAwakeUntilSec > now)
    {
      return;
    }

  // dsp_off() cancels RX_SIG_FOUND before entering Idle.  Prevent a pending
  // acquisition callback from surviving this sleep and firing after a later
  // Idle -> Search transition.
  if (m_acquisitionEvent.IsPending ())
    {
      Simulator::Cancel (m_acquisitionEvent);
    }
  m_mac.SetReceiveState (CsrMacCore::State::IDLE);
}

void
CsrNetDevice::WakeForSignal ()
{
  m_mac.SetReceiveState (CsrMacCore::State::SEARCH);

  double now = Simulator::Now ().GetSeconds ();
  double windowEnd = GetPeriodicWindowEnd (now);
  if (windowEnd > now)
    {
      if (m_sleepEvent.IsPending ())
        {
          Simulator::Cancel (m_sleepEvent);
        }
      m_sleepEvent = Simulator::Schedule (Seconds (windowEnd - now),
                                          &CsrNetDevice::SleepReceiver,
                                          this);
    }
  ScheduleAcquisition ();
}

void
CsrNetDevice::WakeForPendingTx ()
{
  std::cout << "[MAC " << m_id
            << "] pending-TX periodic WAKE at "
            << Simulator::Now ().GetSeconds ()
            << std::endl;
  if (!m_dutyCycleEnabled || !m_mac.HasPendingFrames ())
    {
      RefreshDutyState ();
      return;
    }

  CsrMacCore::State state = m_mac.GetState ();
  if (state == CsrMacCore::State::TRACK ||
      state == CsrMacCore::State::TX)
    {
      return;
    }

  // This is the periodic WAKE -> start_search transition.  PREP_TX is not
  // activated until the first relative 13-ms TSLOT processes the queued
  // frame, matching the source state machine.
  m_mac.SetReceiveState (CsrMacCore::State::SEARCH);

  double now = Simulator::Now ().GetSeconds ();
  double windowEnd = GetPeriodicWindowEnd (now);
  if (windowEnd > now)
    {
      if (m_sleepEvent.IsPending ())
        {
          Simulator::Cancel (m_sleepEvent);
        }
      m_sleepEvent = Simulator::Schedule (
        Seconds (windowEnd - now),
        &CsrNetDevice::SleepReceiver,
        this);
    }
}

void
CsrNetDevice::OpnetPeriodicWake ()
{
  if (!m_dutyCycleEnabled || !m_opnetAlignedDutyCycle)
    {
      return;
    }

  // br_mac handles WAKE in Track/Tx/Search by resetting the timer.  Only an
  // Idle WAKE enters start_search() and starts the no-signal sleep window.
  m_opnetPeriodicWakeEvent = Simulator::Schedule (
    Seconds (m_wakeCycleSec),
    &CsrNetDevice::OpnetPeriodicWake,
    this);
  if (m_mac.GetState () != CsrMacCore::State::IDLE)
    {
      return;
    }

  m_mac.SetReceiveState (CsrMacCore::State::SEARCH);
  if (m_sleepEvent.IsPending ())
    {
      Simulator::Cancel (m_sleepEvent);
    }
  m_sleepEvent = Simulator::Schedule (Seconds (m_awakeWindowSec),
                                      &CsrNetDevice::SleepReceiver,
                                      this);
  ScheduleAcquisition ();
}

void
CsrNetDevice::ScheduleOpnetPeriodicWake ()
{
  if (!m_dutyCycleEnabled ||
      !m_opnetAlignedDutyCycle ||
      m_opnetPeriodicWakeEvent.IsPending ())
    {
      return;
    }

  int64_t cycleSteps = Seconds (m_wakeCycleSec).GetTimeStep ();
  int64_t nowSteps = Simulator::Now ().GetTimeStep ();
  NS_ABORT_MSG_IF (cycleSteps <= 0,
                   "CSR MAC wake cycle must be positive");
  int64_t nextWakeSteps = (nowSteps / cycleSteps + 1) * cycleSteps;
  m_opnetPeriodicWakeEvent = Simulator::Schedule (
    TimeStep (nextWakeSteps - nowSteps),
    &CsrNetDevice::OpnetPeriodicWake,
    this);
}

void
CsrNetDevice::StartPostTxWait ()
{
  CancelPostTxWait ();
  m_postTxWaitActive = true;
  double waitSeconds = GetPostTxWaitSeconds ();
  m_postTxWaitEvent = Simulator::Schedule (
    Seconds (waitSeconds),
    &CsrNetDevice::PostTxWaitExpired,
    this);

  std::cout << "[MAC " << m_id
            << "] post-TX WAIT_FOR_ACK until "
            << (Simulator::Now ().GetSeconds () + waitSeconds)
            << " (POST_TX_WAIT=" << waitSeconds << " s)"
            << std::endl;
}

void
CsrNetDevice::CancelPostTxWait ()
{
  if (m_postTxWaitEvent.IsPending ())
    {
      Simulator::Cancel (m_postTxWaitEvent);
    }
  m_postTxWaitActive = false;
}

void
CsrNetDevice::PostTxWaitExpired ()
{
  m_postTxWaitActive = false;

  CsrMacCore::State state = m_mac.GetState ();
  if (state == CsrMacCore::State::TRACK ||
      state == CsrMacCore::State::TX)
    {
      // br_mac Track consumes POST_TX_WAIT by clearing WAIT_FOR_ACK only.
      // If the tracked packet later completes with no queued work,
      // back2search() owns a fresh 7.8-ms no-signal Search.
      return;
    }

  if (!m_dutyCycleEnabled)
    {
      RefreshDutyState ();
      return;
    }

  // Search consumes POST_TX_WAIT through the same dsp_off() transition as a
  // SLEEP interrupt.  This is event-owned and does not depend on the current
  // periodic wake phase.
  if (m_sleepEvent.IsPending ())
    {
      Simulator::Cancel (m_sleepEvent);
    }
  if (m_acquisitionEvent.IsPending ())
    {
      Simulator::Cancel (m_acquisitionEvent);
    }
  m_mac.SetReceiveState (CsrMacCore::State::IDLE);
}

void
CsrNetDevice::ScheduleSignalWake ()
{
  if (!m_dutyCycleEnabled ||
      m_opnetAlignedDutyCycle ||
      m_mac.GetState () != CsrMacCore::State::IDLE ||
      m_signalWakeEvent.IsPending ())
    {
      return;
    }

  double now = Simulator::Now ().GetSeconds ();
  double wakeTime = GetNextPeriodicWake (now);
  bool canAcquire = false;
  for (const auto &[id, signal] : m_rxSignals)
    {
      (void) id;
      if (signal.syncEligible &&
          signal.preambleActive &&
          !signal.rejected &&
          wakeTime + m_syncToTrackSec < signal.preambleEndSec)
        {
          canAcquire = true;
          break;
        }
    }

  if (canAcquire)
    {
      m_signalWakeEvent = Simulator::Schedule (
        Seconds (std::max (0.0, wakeTime - now)),
        &CsrNetDevice::WakeForSignal,
        this);
    }
}

void
CsrNetDevice::SchedulePendingTxWake ()
{
  if (!m_dutyCycleEnabled ||
      m_opnetAlignedDutyCycle ||
      m_mac.GetState () != CsrMacCore::State::IDLE ||
      !m_mac.HasPendingFrames () ||
      m_pendingTxWakeEvent.IsPending ())
    {
      return;
    }

  double now = Simulator::Now ().GetSeconds ();
  double wakeTime = GetNextPeriodicWake (now);
  std::cout << "[MAC " << m_id
            << "] Idle RTS defers to nearby periodic WAKE at "
            << wakeTime
            << std::endl;
  m_pendingTxWakeEvent = Simulator::Schedule (
    Seconds (std::max (0.0, wakeTime - now)),
    &CsrNetDevice::WakeForPendingTx,
    this);
}

void
CsrNetDevice::UpdateSyncPresence ()
{
  bool present = false;
  for (const auto &[id, signal] : m_rxSignals)
    {
      (void) id;
      if (signal.syncEligible && signal.preambleActive)
        {
          present = true;
          break;
        }
    }
  m_mac.SetSyncPresent (present);
}

void
CsrNetDevice::ScheduleAcquisition ()
{
  if (m_mac.GetState () != CsrMacCore::State::SEARCH ||
      !m_mac.IsSyncPresent () ||
      m_acquisitionEvent.IsPending ())
    {
      return;
    }

  m_acquisitionEvent = Simulator::Schedule (Seconds (m_syncToTrackSec),
                                             &CsrNetDevice::AcquireSignal,
                                             this);
}

void
CsrNetDevice::ReturnToSearchAfterReceive ()
{
  // br_mac's Track --DONE_RX_PK--> Search transition runs back2search().
  // Unlike start_search(), this path does not include DSP_RX_BOOTTIME.  When
  // no ACK/Tx preparation or post-Tx ACK wait owns the receiver, it schedules
  // SLEEP after exactly NO_SIG_SRH_TIME (7.8 ms).  A subsequent acquisition
  // cancels that event when it enters Track.
  // A preamble admitted during Track is rejected for that Track epoch, but it
  // stays in the source SYNC table.  back2search() does not change its
  // PK_ACCEPT value.  It becomes an acquisition candidate again, and only
  // start_track() explicitly restores PK_ACCEPT=true on the selected signal.

  m_mac.SetReceiveState (CsrMacCore::State::SEARCH);
  ScheduleAcquisition ();

  if (m_sleepEvent.IsPending ())
    {
      Simulator::Cancel (m_sleepEvent);
    }

  if (!m_dutyCycleEnabled)
    {
      return;
    }

  bool preparationKeepsSearch = m_mac.IsTxPreparationActive ();
  bool waitingForAck = m_postTxWaitActive;
  if (preparationKeepsSearch || waitingForAck ||
      m_mac.GetState () != CsrMacCore::State::SEARCH)
    {
      return;
    }

  m_sleepEvent = Simulator::Schedule (
    Seconds (m_noSignalSearchSec),
    &CsrNetDevice::SleepReceiver,
    this);
}

void
CsrNetDevice::ReturnRejectedReceiveToSearch ()
{
  if (m_mac.GetState () == CsrMacCore::State::TRACK)
    {
      ReturnToSearchAfterReceive ();
      return;
    }
  RefreshDutyState ();
}

void
CsrNetDevice::UpdateSignalNoise (RxSignal &signal)
{
  signal.currentInterferenceWatts = 0.0;
  for (const auto &[interfererId, powerWatts] :
       signal.additiveInterferenceWatts)
    {
      (void) interfererId;
      signal.currentInterferenceWatts += powerWatts;
    }
  double totalNoiseWatts = signal.frontEnd.backgroundNoiseWatts +
    signal.currentInterferenceWatts;
  signal.peakNoiseWatts = std::max (signal.peakNoiseWatts,
                                    totalNoiseWatts);
  signal.snrDb = CsrPhyModel::ComputeSnrDb (
    signal.frontEnd.receivedPowerWatts,
    totalNoiseWatts);
}

void
CsrNetDevice::CloseSignalInterval (RxSignal &signal, double endSec)
{
  double boundedEndSec = std::min (endSec, signal.endSec);
  if (boundedEndSec <= signal.intervalStartSec)
    {
      return;
    }

  CsrBerInterval interval;
  interval.startSec = signal.intervalStartSec;
  interval.endSec = boundedEndSec;
  interval.noisePowerWatts = signal.frontEnd.backgroundNoiseWatts +
    signal.currentInterferenceWatts;
  interval.collisionCount = signal.collisionCount;
  // Preserve br_ber's receiver-global last-collision state for the S0 header
  // and supplied spread-rate curves.  The high-rate payload fallback carries
  // a separate, signed per-signal jammer ratio so a stronger or shorter
  // jammer is represented only over the interval where it is active.
  interval.sameRateInterference = m_rxSameSpeed;
  interval.jsrDb = m_rxJsrDb;
  interval.timeOffsetSeconds = m_rxTimeOffsetSeconds;
  if (CsrIsHighRateDifferentialMode (signal.rateKbps))
    {
      interval.highRatePayloadJammer = signal.sameRateInterference;
      interval.highRatePayloadJsrDb = signal.jsrDb;
    }
  signal.berIntervals.push_back (interval);
  uint32_t preambleBits = signal.preamble == PREAMBLE_LONG ? 7888 : 104;
  CsrErrorAllocation allocated = m_phy.AllocateErrors (
    signal.frontEnd,
    signal.startSec,
    preambleBits,
    signal.packetBits,
    signal.rateKbps,
    {interval},
    m_rng);
  signal.errorAllocation.headerBits += allocated.headerBits;
  signal.errorAllocation.payloadBits += allocated.payloadBits;
  signal.errorAllocation.headerErrors += allocated.headerErrors;
  signal.errorAllocation.payloadErrors += allocated.payloadErrors;
  signal.errorAllocation.totalErrors += allocated.totalErrors;
  signal.errorAllocation.actualBer = allocated.actualBer;
  signal.errorAllocation.headerBer = allocated.headerBer;
  signal.errorAllocation.payloadBer = allocated.payloadBer;
  signal.errorAllocation.minimumSnrDb = std::min (
    signal.errorAllocation.minimumSnrDb,
    allocated.minimumSnrDb);
  signal.errorAllocation.peakNoisePowerWatts = std::max (
    signal.errorAllocation.peakNoisePowerWatts,
    allocated.peakNoisePowerWatts);
  signal.errorAllocation.packetErrorProbability = 1.0 -
    (1.0 - signal.errorAllocation.packetErrorProbability) *
    (1.0 - allocated.packetErrorProbability);
  signal.intervalStartSec = boundedEndSec;
}

void
CsrNetDevice::CloseAllSignalIntervals (double endSec)
{
  for (auto &[id, signal] : m_rxSignals)
    {
      (void) id;
      CloseSignalInterval (signal, endSec);
    }
}

void
CsrNetDevice::StartAllSignalIntervals (double startSec)
{
  for (auto &[id, signal] : m_rxSignals)
    {
      (void) id;
      signal.intervalStartSec = std::min (startSec, signal.endSec);
    }
}

void
CsrNetDevice::RecordSameRateInterference (RxSignal &desired,
                                           const RxSignal &jammer)
{
  if (!desired.frontEnd.channelMatched ||
      !jammer.frontEnd.channelMatched ||
      desired.frontEnd.receivedPowerWatts <= 0.0 ||
      jammer.frontEnd.receivedPowerWatts <= 0.0)
    {
      return;
    }

  double jsrDb = jammer.rxPowerDbm - desired.rxPowerDbm;
  if (!desired.sameRateInterference || jsrDb > desired.jsrDb)
    {
      desired.sameRateInterference = true;
      desired.jsrDb = jsrDb;
      desired.timeOffsetSeconds = jammer.startSec - desired.startSec;
    }
}

void
CsrNetDevice::RefreshHighRateInterference ()
{
  // The fallback is interval-local, unlike br_ber's receiver-global
  // diagnostic collision record.  Rebuild each active high-rate signal from
  // the currently overlapping signals whenever an interference boundary
  // removes a jammer.
  for (auto &[desiredId, desired] : m_rxSignals)
    {
      (void) desiredId;
      if (!CsrIsHighRateDifferentialMode (desired.rateKbps))
        {
          continue;
        }
      desired.sameRateInterference = false;
      desired.jsrDb = -std::numeric_limits<double>::infinity ();
      desired.timeOffsetSeconds = 0.0;
    }

  for (auto desiredIt = m_rxSignals.begin ();
       desiredIt != m_rxSignals.end ();
       ++desiredIt)
    {
      RxSignal &desired = desiredIt->second;
      if (!CsrIsHighRateDifferentialMode (desired.rateKbps))
        {
          continue;
        }
      if (desired.rejected)
        {
          continue;
        }
      for (auto jammerIt = m_rxSignals.begin ();
           jammerIt != m_rxSignals.end ();
           ++jammerIt)
        {
          if (jammerIt == desiredIt ||
              jammerIt->second.rateKbps != desired.rateKbps)
            {
              continue;
            }
          RecordSameRateInterference (desired, jammerIt->second);
        }
    }
}

void
CsrNetDevice::ApplyInterferencePair (RxSignal &first,
                                      RxSignal &second)
{
  double now = Simulator::Now ().GetSeconds ();
  if (!first.frontEnd.channelMatched ||
      !second.frontEnd.channelMatched ||
      first.endSec <= now ||
      second.endSec <= now)
    {
      return;
    }

  first.collisionCount++;
  second.collisionCount++;
  // Apply br_inoise's USE_PK_ACCEPT_TDA branch.  The arriving signal (first)
  // has just been reset to accepted by br_power; a previous signal may have
  // been rejected by mark_sync(), clear_sync(), or start_track().
  bool firstAccepted = !first.rejected;
  bool secondAccepted = !second.rejected;
  if (first.rateKbps == second.rateKbps)
    {
      m_rxSameSpeed = true;
      if (firstAccepted && secondAccepted)
        {
          // A tie takes the source's else branch: the previous packet is the
          // desired signal and the arriving packet is its jammer.
          const RxSignal &desired = first.rxPowerDbm > second.rxPowerDbm
            ? first
            : second;
          const RxSignal &jammer = first.rxPowerDbm > second.rxPowerDbm
            ? second
            : first;
          m_rxJsrDb = jammer.rxPowerDbm - desired.rxPowerDbm;
          m_rxTimeOffsetSeconds = jammer.startSec - desired.startSec;
        }
      else if (firstAccepted)
        {
          m_rxJsrDb = second.rxPowerDbm - first.rxPowerDbm;
          m_rxTimeOffsetSeconds = second.startSec - first.startSec;
        }
      else if (secondAccepted)
        {
          m_rxJsrDb = first.rxPowerDbm - second.rxPowerDbm;
          m_rxTimeOffsetSeconds = first.startSec - second.startSec;
        }

      // The high-rate extension has no recovered JSR tables, but its
      // documented jammer-as-noise fallback still follows the same source
      // PK_ACCEPT orientation.
      if (firstAccepted)
        {
          RecordSameRateInterference (first, second);
        }
      if (secondAccepted)
        {
          RecordSameRateInterference (second, first);
        }
      return;
    }

  m_rxSameSpeed = false;
  // Different-speed power is added only to packets whose PK_ACCEPT is true.
  // Retain the contributor identity so its END_RX removes exactly the power
  // that this pair added, including asymmetric one-accepted cases.
  if (firstAccepted)
    {
      first.additiveInterferenceWatts[second.id] =
        second.frontEnd.receivedPowerWatts;
    }
  if (secondAccepted)
    {
      second.additiveInterferenceWatts[first.id] =
        first.frontEnd.receivedPowerWatts;
    }
  UpdateSignalNoise (first);
  UpdateSignalNoise (second);
}

void
CsrNetDevice::RemoveEndedInterference (const RxSignal &ended)
{
  for (auto &[signalId, signal] : m_rxSignals)
    {
      if (signalId == ended.id)
        {
          continue;
        }
      signal.additiveInterferenceWatts.erase (ended.id);
      UpdateSignalNoise (signal);
    }
}

void
CsrNetDevice::ApplyTrackedInterference (RxSignal &interferer)
{
  auto trackedIt = m_rxSignals.find (m_trackedSignalId);
  if (trackedIt == m_rxSignals.end ())
    {
      return;
    }

  RxSignal &tracked = trackedIt->second;
  interferer.rejected = true;
  interferer.rejectedDuringTrack = true;
  if (!interferer.frontEnd.channelMatched ||
      tracked.rateKbps != interferer.rateKbps)
    {
      return;
    }

  double desiredMarginDb = tracked.rxPowerDbm - interferer.rxPowerDbm;
  if (desiredMarginDb >= m_captureMarginDb)
    {
      m_rxCaptureCount++;
    }
  else
    {
      tracked.collided = true;
    }
}

double
CsrNetDevice::DrawSyncSnrThresholdDb ()
{
  if (m_syncThresholdOverrideDb.has_value ())
    {
      return *m_syncThresholdOverrideDb;
    }

  const CsrPhyProfile &profile = m_phy.profile;
  NS_ABORT_MSG_IF (!std::isfinite (profile.syncSnrThresholdDb) ||
                   !std::isfinite (
                     profile.syncSnrThresholdVarianceDb2) ||
                   profile.syncSnrThresholdVarianceDb2 < 0.0,
                   "CSR SYNC threshold distribution is invalid");
  if (!profile.stochasticSyncThreshold ||
      profile.syncSnrThresholdVarianceDb2 == 0.0)
    {
      return profile.syncSnrThresholdDb;
    }

  return m_syncThresholdRng->GetValue (
    profile.syncSnrThresholdDb,
    profile.syncSnrThresholdVarianceDb2);
}

void
CsrNetDevice::BeginReceiveSignal (RxSignal signal)
{
  double now = Simulator::Now ().GetSeconds ();
  signal.arrivalOrder = ++m_nextRxArrivalOrder;
  double distanceMeters = m_phy.GetDistanceMeters (signal.txId, m_id);
  signal.frontEnd = m_phy.ComputeFrontEnd (
    signal.txPowerDbm,
    distanceMeters,
    signal.txRadio);
  signal.pathlossDb = signal.frontEnd.pathlossDb;
  signal.rxPowerDbm = signal.frontEnd.receivedPowerDbm;
  signal.intervalStartSec = now;
  UpdateSignalNoise (signal);

  bool hadSync = m_mac.IsSyncPresent ();
  CloseAllSignalIntervals (now);
  auto [it, inserted] = m_rxSignals.emplace (signal.id, std::move (signal));
  NS_ASSERT_MSG (inserted, "duplicate CSR receive signal identifier");
  RxSignal &incoming = it->second;

  std::vector<RxSignal *> previousSignals;
  previousSignals.reserve (m_rxSignals.size () - 1);
  for (auto &[otherId, other] : m_rxSignals)
    {
      if (otherId != incoming.id)
        {
          previousSignals.push_back (&other);
        }
    }
  std::sort (previousSignals.begin (),
             previousSignals.end (),
             [] (const RxSignal *left, const RxSignal *right) {
               return left->arrivalOrder < right->arrivalOrder;
             });
  for (RxSignal *previous : previousSignals)
    {
      // br_inoise receives each pre-existing packet in pipeline order.  Its
      // channel-wide same_speed/JSR/offset values are overwritten on every
      // pair, so preserve prior arrival order instead of std::map signal-ID
      // order.
      ApplyInterferencePair (incoming, *previous);
    }
  StartAllSignalIntervals (now);
  if (incoming.frontEnd.channelMatched)
    {
      double syncThresholdDb = DrawSyncSnrThresholdDb ();
      incoming.syncEligible = incoming.snrDb >= syncThresholdDb;
      if (!incoming.syncEligible)
        {
          // mark_sync() writes PK_ACCEPT=false for a below-threshold SYNC.
          // Keep that state for any later br_inoise pair while this packet is
          // still physically present in the receiver pipeline.
          incoming.rejected = true;
        }
      m_syncDecisionTrace (incoming.txId,
                           incoming.sequence,
                           incoming.snrDb,
                           syncThresholdDb,
                           incoming.syncEligible);
    }

  // mark_sync() returns before adding a rejected signal to the SYNC table
  // or scheduling SYNC_END. Its physical end must not cancel acquisition of
  // another signal through clear_sync(). The signal still contributes to
  // the PHY pipeline until END_RX below.
  if (incoming.syncEligible)
    {
      Simulator::Schedule (
        Seconds (std::max (0.0, incoming.preambleEndSec - now)),
        &CsrNetDevice::EndReceivePreamble,
        this,
        incoming.id);
    }
  else
    {
      incoming.preambleActive = false;
    }
  Simulator::Schedule (
    Seconds (std::max (0.0, incoming.endSec - now)),
    &CsrNetDevice::EndReceiveSignal,
    this,
    incoming.id);

  CsrMacCore::State state = m_mac.GetState ();
  if (state == CsrMacCore::State::TX)
    {
      incoming.missedByState = true;
      if (incoming.syncEligible)
        {
          m_rxCollisionCount++;
        }
    }
  else if (state == CsrMacCore::State::TRACK)
    {
      if (incoming.syncEligible)
        {
          m_rxCollisionCount++;
        }
      ApplyTrackedInterference (incoming);
    }
  else if (incoming.syncEligible && hadSync)
    {
      m_rxCollisionCount++;
    }

  UpdateSyncPresence ();
  RefreshDutyState ();

  if (m_mac.GetState () == CsrMacCore::State::SEARCH)
    {
      ScheduleAcquisition ();
    }
  else if (m_mac.GetState () == CsrMacCore::State::IDLE)
    {
      incoming.missedByState = true;
      ScheduleSignalWake ();
    }

  std::cout << "[t=" << now << "] RX SYNC at node " << m_id
            << " from node " << incoming.txId
            << " seq " << incoming.sequence
            << " power " << incoming.rxPowerDbm << " dBm"
            << " noise "
            << CsrPhyModel::WattsToDbm (
                 incoming.frontEnd.backgroundNoiseWatts +
                 incoming.currentInterferenceWatts)
            << " dBm"
            << " snr " << incoming.snrDb << " dB"
            << " state=" << static_cast<int> (m_mac.GetState ())
            << (incoming.frontEnd.channelMatched
                  ? (incoming.syncEligible ? "" : " below-threshold")
                  : " channel-mismatch")
            << std::endl;
}

void
CsrNetDevice::EndReceivePreamble (uint64_t signalId)
{
  auto it = m_rxSignals.find (signalId);
  if (it == m_rxSignals.end ())
    {
      return;
    }

  it->second.preambleActive = false;

  // clear_sync() rejects an expired preamble whenever the MAC is outside
  // Track.  The packet can remain in the receiver pipeline after that point,
  // so a later overlap must observe PK_ACCEPT=false.
  if (m_mac.GetState () != CsrMacCore::State::TRACK)
    {
      it->second.rejected = true;
    }

  // clear_sync() cancels the outstanding RX_SIG_FOUND event whenever any
  // preamble expires.  Preserve that ordering, including the multi-signal
  // behavior of the supplied process model.
  if (m_acquisitionEvent.IsPending ())
    {
      Simulator::Cancel (m_acquisitionEvent);
    }
  UpdateSyncPresence ();
}

void
CsrNetDevice::AcquireSignal ()
{
  if (m_mac.GetState () != CsrMacCore::State::SEARCH)
    {
      return;
    }

  double now = Simulator::Now ().GetSeconds ();
  std::vector<RxSignal *> candidates;
  for (auto &[id, signal] : m_rxSignals)
    {
      (void) id;
      if (signal.syncEligible &&
          signal.preambleActive &&
          (!signal.rejected || signal.rejectedDuringTrack))
        {
          candidates.push_back (&signal);
        }
    }

  if (candidates.empty ())
    {
      return;
    }

  std::sort (candidates.begin (),
             candidates.end (),
             [] (const RxSignal *left, const RxSignal *right) {
               if (left->startSec != right->startSec)
                 {
                   return left->startSec < right->startSec;
                 }
               return left->arrivalOrder < right->arrivalOrder;
             });

  RxSignal *selected = candidates.front ();
  for (std::size_t index = 1; index < candidates.size (); ++index)
    {
      RxSignal *candidate = candidates[index];
      if (now - candidate->startSec > m_syncToTrackSec &&
          candidate->rxPowerDbm > selected->rxPowerDbm)
        {
          selected = candidate;
        }
    }

  // Snapshot the receiver-global br_inoise state through the exact
  // start_track() boundary.  The JSR/offset overwrite below applies only to
  // the following interval; it must not be retroactively attached to time
  // elapsed while the receiver was still in Search.
  CloseAllSignalIntervals (now);

  // start_track() explicitly accepts the chosen packet, including a surviving
  // preamble that the preceding Track epoch rejected.
  selected->rejected = false;
  selected->rejectedDuringTrack = false;
  selected->tracked = true;
  selected->missedByState = false;
  m_trackedSignalId = selected->id;

  RxSignal *strongestRejected = nullptr;
  double strongestSameRateJammerDbm =
    -std::numeric_limits<double>::infinity ();
  for (RxSignal *other : candidates)
    {
      if (other == selected)
        {
          continue;
        }
      other->rejected = true;
      other->rejectedDuringTrack = true;
      if (strongestRejected == nullptr ||
          other->rxPowerDbm > strongestRejected->rxPowerDbm)
        {
          strongestRejected = other;
        }
      if (other->rateKbps == selected->rateKbps &&
          other->frontEnd.channelMatched)
        {
          strongestSameRateJammerDbm = std::max (
            strongestSameRateJammerDbm,
            other->rxPowerDbm);
        }
    }

  if (strongestRejected != nullptr)
    {
      // start_track() overwrites the receiver channel's singleton JSR and
      // offset with the chosen signal and strongest rejected candidate.  It
      // does this without a speed check; same_speed remains whatever the last
      // br_inoise pair stored.
      m_rxJsrDb = strongestRejected->rxPowerDbm - selected->rxPowerDbm;
      m_rxTimeOffsetSeconds =
        strongestRejected->startSec - selected->startSec;
    }

  if (std::isfinite (strongestSameRateJammerDbm))
    {
      if (selected->rxPowerDbm - strongestSameRateJammerDbm >=
          m_captureMarginDb)
        {
          m_rxCaptureCount++;
        }
      else
        {
          selected->collided = true;
        }
    }

  StartAllSignalIntervals (now);

  if (m_sleepEvent.IsPending ())
    {
      Simulator::Cancel (m_sleepEvent);
    }
  m_mac.SetReceiveState (CsrMacCore::State::TRACK);

  std::cout << "[t=" << now << "] MAC " << m_id
            << " enters Track on node " << selected->txId
            << " seq " << selected->sequence
            << " power " << selected->rxPowerDbm << " dBm"
            << (selected->collided ? " collided" : "")
            << std::endl;
}

void
CsrNetDevice::DeliverTrackedSignal (const RxSignal &signal,
                                    const CsrRxDecision &decision)
{
  bool addressedFrame = false;
  for (const auto &segment : signal.frames)
    {
      CsrHeader header;
      segment->PeekHeader (header);
      if (header.IsForDestination (m_id))
        {
          addressedFrame = true;
        }
    }

  double now = Simulator::Now ().GetSeconds ();
  std::cout << "[t=" << now << "] "
            << (addressedFrame ? "RX" : "RX OVERHEARD")
            << " at node " << m_id
            << " from node " << signal.txId
            << " seq " << signal.sequence
            << " rate " << signal.rateKbps << " kbps"
            << " txPower " << signal.txPowerDbm << " dBm"
            << " preamble "
            << (signal.preamble == PREAMBLE_LONG ? "LONG" : "SHORT")
            << " pathloss " << decision.pathlossDb << " dB"
            << " snr " << decision.snrDb << " dB"
            << " (slot " << signal.reservedSlot
            << ", len " << signal.payloadBytes << "B"
            << ", ackable=" << (signal.ackable ? 1 : 0) << ")"
            << std::endl;

  m_mac.NoteHeardFrom (signal.txId, now);
  m_mac.SetNeighborPathloss (signal.txId, decision.pathlossDb);
  if (signal.reservedSlot >= 0)
    {
      m_mac.NoteNeighborReservedSlot (signal.txId,
                                      signal.reservedSlot);
    }

  // OPNET MAC forwards every decoded segment to HOP and lets HOP perform
  // destination filtering after recording the source-neighbor observation.
  for (const auto &segment : signal.frames)
    {
      m_mac.DeliverRxFrameToUp (segment->Copy (),
                                decision.pathlossDb,
                                decision.snrDb);
    }
}

void
CsrNetDevice::EndReceiveSignal (uint64_t signalId)
{
  auto it = m_rxSignals.find (signalId);
  if (it == m_rxSignals.end ())
    {
      return;
    }

  double now = Simulator::Now ().GetSeconds ();
  CloseAllSignalIntervals (now);
  RxSignal signal = it->second;
  bool wasTracked = signalId == m_trackedSignalId;
  bool pipelineRejectedTracked = false;
  if (wasTracked)
    {
      uint32_t preambleBits = signal.preamble == PREAMBLE_LONG
        ? 7888
        : 104;
      bool stateAllowsDelivery =
        m_mac.GetState () == CsrMacCore::State::TRACK;
      bool priorAccepted = stateAllowsDelivery && !signal.rejected;
      CsrRxDecision decision = m_phy.EvaluateAllocatedRx (
        signal.frontEnd,
        preambleBits,
        signal.packetBits,
        signal.errorAllocation,
        signal.berIntervals,
        priorAccepted,
        false,
        false);
      decision.closure = true;
      if (m_phy.UsesCustomErrorModel ())
        {
          // Existing MAC-state tests use a zero-error hook to isolate the
          // pre-table collision gate from stochastic PHY behavior.
          decision.success = decision.success && !signal.collided;
        }
      m_lastRxDecision = decision;
      m_hasLastRxDecision = true;
      pipelineRejectedTracked = !decision.success;
      if (decision.eccDropped)
        {
          m_rxEccDropCount++;
        }

      if (g_rxCsv.is_open ())
        {
          g_rxCsv << now << ","
                  << signal.txId << ","
                  << m_id << ","
                  << signal.sequence << ","
                  << signal.rateKbps << ","
                  << signal.packetBits << ","
                  << signal.frontEnd.distanceMeters << ","
                  << static_cast<int> (decision.pathModel) << ","
                  << signal.frontEnd.bandOverlapHz << ","
                  << decision.pathlossDb << ","
                  << decision.receivedPowerDbm << ","
                  << decision.noisePowerDbm << ","
                  << decision.snrDb << ","
                  << (decision.sameRateInterference ? 1 : 0) << ","
                  << decision.jsrDb << ","
                  << decision.timeOffsetSeconds << ","
                  << decision.per << ","
                  << decision.headerBer << ","
                  << decision.payloadBer << ","
                  << decision.actualBer << ","
                  << decision.headerErrors << ","
                  << decision.payloadErrors << ","
                  << decision.totalErrors << ","
                  << decision.protectedBits << ","
                  << decision.correctableBits << ","
                  << (decision.eccDropped ? 1 : 0) << ","
                  << (decision.success ? 1 : 0)
                  << "\n";
        }

      CsrHeader traceHeader;
      signal.frames.front ()->PeekHeader (traceHeader);
      CsrDifferentialTraceEvent rxEvent;
      rxEvent.event = decision.success ? "rx_accept" : "rx_drop";
      rxEvent.node = CsrTraceInteger (m_id);
      rxEvent.peer = CsrTraceInteger (signal.txId);
      rxEvent.packetType = CsrPacketTypeName (traceHeader.GetType ());
      rxEvent.source = CsrTraceInteger (traceHeader.GetSrc ());
      rxEvent.destination = CsrTraceInteger (traceHeader.GetDst ());
      rxEvent.sequence = CsrTraceInteger (signal.sequence);
      rxEvent.rateKbps = CsrTraceSignedInteger (signal.rateKbps);
      rxEvent.sizeBytes = CsrTraceInteger (signal.payloadBytes);
      rxEvent.success = decision.success ? "1" : "0";
      rxEvent.reason = decision.success
        ? "accepted"
        : (decision.eccDropped
             ? "ecc"
             : (signal.collided
                  ? "collision"
                  : (stateAllowsDelivery ? "phy" : "state")));
      rxEvent.pathlossDb = CsrTraceDouble (decision.pathlossDb);
      rxEvent.rxPowerDbm = CsrTraceDouble (decision.receivedPowerDbm);
      rxEvent.noiseDbm = CsrTraceDouble (decision.noisePowerDbm);
      rxEvent.snrDb = CsrTraceDouble (decision.snrDb);
      rxEvent.jsrDb = CsrTraceDouble (decision.jsrDb);
      rxEvent.headerErrors = CsrTraceInteger (decision.headerErrors);
      rxEvent.payloadErrors = CsrTraceInteger (decision.payloadErrors);
      rxEvent.totalErrors = CsrTraceInteger (decision.totalErrors);
      rxEvent.detail = "collisions=" + CsrTraceInteger (
        signal.collisionCount);
      if (traceHeader.HasSecurityCount ())
        {
          rxEvent.securityCount = CsrTraceInteger (
            traceHeader.GetSecurityCount ());
        }
      WriteDifferentialTrace (rxEvent);

      if (decision.success)
        {
          DeliverTrackedSignal (signal, decision);
        }
      else
        {
          std::cout << "[t=" << Simulator::Now ().GetSeconds ()
                    << "] RX DROP at node " << m_id
                    << " from node " << signal.txId
                    << " seq " << signal.sequence
                    << (signal.collided ? " (collision)" : " (PHY/state)")
                    << std::endl;
        }

      m_trackedSignalId = 0;
    }
  else
    {
      if (signal.missedByState)
        {
          m_rxMissCount++;
        }
      CsrHeader traceHeader;
      signal.frames.front ()->PeekHeader (traceHeader);
      CsrDifferentialTraceEvent missEvent;
      missEvent.event = "rx_drop";
      missEvent.node = CsrTraceInteger (m_id);
      missEvent.peer = CsrTraceInteger (signal.txId);
      missEvent.packetType = CsrPacketTypeName (traceHeader.GetType ());
      missEvent.source = CsrTraceInteger (traceHeader.GetSrc ());
      missEvent.destination = CsrTraceInteger (traceHeader.GetDst ());
      missEvent.sequence = CsrTraceInteger (signal.sequence);
      missEvent.rateKbps = CsrTraceSignedInteger (signal.rateKbps);
      missEvent.sizeBytes = CsrTraceInteger (signal.payloadBytes);
      missEvent.success = "0";
      // br_mac clears PK_ACCEPT for a signal that expires outside Track,
      // loses acquisition, or arrives while another signal is tracked.
      // br_ecc excludes those prior-stage rejections from its drop statistic.
      // A receiver still in Tx is instead rejected by signal_lock.
      missEvent.reason = m_mac.GetState () == CsrMacCore::State::TX
        ? "half_duplex"
        : "prior_stage";
      missEvent.pathlossDb = CsrTraceDouble (signal.pathlossDb);
      missEvent.rxPowerDbm = CsrTraceDouble (signal.rxPowerDbm);
      missEvent.noiseDbm = CsrTraceDouble (
        CsrPhyModel::WattsToDbm (
          signal.errorAllocation.peakNoisePowerWatts));
      missEvent.snrDb = CsrTraceDouble (
        signal.errorAllocation.minimumSnrDb);
      missEvent.jsrDb = CsrTraceDouble (signal.jsrDb);
      missEvent.headerErrors = CsrTraceInteger (
        signal.errorAllocation.headerErrors);
      missEvent.payloadErrors = CsrTraceInteger (
        signal.errorAllocation.payloadErrors);
      missEvent.totalErrors = CsrTraceInteger (
        signal.errorAllocation.totalErrors);
      missEvent.detail = "collisions=" + CsrTraceInteger (
        signal.collisionCount);
      WriteDifferentialTrace (missEvent);
      if (signal.missedByState)
        {
          std::cout << "[t=" << Simulator::Now ().GetSeconds ()
                    << "] RX MISS at node " << m_id
                    << " from node " << signal.txId
                    << " seq " << signal.sequence
                    << std::endl;
        }
    }

  RemoveEndedInterference (signal);
  m_rxSignals.erase (it);
  RefreshHighRateInterference ();
  StartAllSignalIntervals (now);
  UpdateSyncPresence ();

  if (wasTracked && m_mac.GetState () != CsrMacCore::State::TX)
    {
      if (pipelineRejectedTracked)
        {
          // start_track() installs a fallback DONE_RX_PK at END_RX + TIC for
          // packets suppressed by the receiver pipeline.  A delivered packet
          // instead runs proc_rx_pk() and returns immediately at END_RX.
          m_doneRxEvent = Simulator::Schedule (
            CsrOpnetTic (),
            &CsrNetDevice::ReturnRejectedReceiveToSearch,
            this);
        }
      else
        {
          ReturnToSearchAfterReceive ();
        }
    }
  else
    {
      RefreshDutyState ();
    }
}

void
CsrNetDevice::OnMacTxFinished (bool queuesEmpty)
{
  UpdateSyncPresence ();
  if (queuesEmpty)
    {
      StartPostTxWait ();
    }
  ScheduleAcquisition ();
  RefreshDutyState ();
}

// ------------------------------------------------------------
// CsrMacCore implementation
// ------------------------------------------------------------

bool
CsrMacCore::HasPendingFrame () const
{
  return !m_ackQueue.empty () || !m_queue.empty ();
}

void
CsrMacCore::EnqueueAckFrame (Ptr<Packet> frame,
                             const CsrHeader &header)
{
  CsrNodeId dest = header.GetDst ();
  uint16_t seq = header.GetSeq ();

  if (header.HasAckWindow ())
    {
      // OPNET replaces the first cumulative ACK/DACK entry for a destination
      // and restarts its transmission count.  It does this even when the ACK
      // queue is already at its capacity.
      for (auto &entry : m_ackQueue)
        {
          if (entry.dest == dest)
            {
  Tranche9MacSnapshot ("ack_queue_replace_before", m_nodeId, dest, StateName (m_state),
    m_txPreparationActive, m_txHoldoffOver, m_syncPresent,
    m_ackQueue.size (), m_queue.size (), m_txInProgress,
    m_scheduledTxSlot, m_txCountdownCounter, frame, entry.frame, std::string ("prior_tx_count=") + CsrTraceInteger (entry.txCount));
              entry.frame = frame;
              entry.seq = seq;
              entry.hasWindow = true;
              entry.txCount = 0;
  Tranche9MacSnapshot ("ack_queue_replace_after", m_nodeId, dest, StateName (m_state),
    m_txPreparationActive, m_txHoldoffOver, m_syncPresent,
    m_ackQueue.size (), m_queue.size (), m_txInProgress,
    m_scheduledTxSlot, m_txCountdownCounter, frame, nullptr, "");

              std::cout << "[MAC " << m_nodeId
                        << "] Update cumulative ACK queue entry"
                        << " dest=" << dest
                        << " baseSeq=" << seq
                        << " txCount=0"
                        << std::endl;

              MaybeScheduleNextTx ();
              return;
            }
        }
    }
  else
    {
      // Exact ACKs are retained only once for a destination/sequence pair.
      for (const auto &entry : m_ackQueue)
        {
          if (entry.dest == dest && entry.seq == seq)
            {
  Tranche9MacSnapshot ("ack_queue_exact_duplicate", m_nodeId, dest, StateName (m_state),
    m_txPreparationActive, m_txHoldoffOver, m_syncPresent,
    m_ackQueue.size (), m_queue.size (), m_txInProgress,
    m_scheduledTxSlot, m_txCountdownCounter, frame, entry.frame, "");
              std::cout << "[MAC " << m_nodeId
                        << "] Ignore duplicate exact ACK"
                        << " dest=" << dest
                        << " seq=" << seq
                        << std::endl;
              return;
            }
        }
    }

  if (m_ackQueue.size () >= ACK_QUEUE_SIZE)
    {
  Tranche9MacSnapshot ("ack_queue_reject", m_nodeId, dest, StateName (m_state),
    m_txPreparationActive, m_txHoldoffOver, m_syncPresent,
    m_ackQueue.size (), m_queue.size (), m_txInProgress,
    m_scheduledTxSlot, m_txCountdownCounter, frame, nullptr, "");
      std::cout << "[MAC " << m_nodeId
                << "] Drop ACK: OPNET ACK queue limit reached"
                << " dest=" << dest
                << " seq=" << seq
                << " limit=" << ACK_QUEUE_SIZE
                << std::endl;
      // br_mac writes the unchanged full-queue value on this rejection.
      WriteDifferentialStatisticSample (
        m_nodeId,
        CSR_STAT_MAC_ACK_QUEUE_SIZE,
        static_cast<double> (m_ackQueue.size ()));
      return;
    }

  AckQueueEntry entry;
  entry.frame = frame;
  entry.dest = dest;
  entry.seq = seq;
  entry.hasWindow = header.HasAckWindow ();
  entry.txCount = 0;
  m_ackQueue.push_back (entry);
  Tranche9MacSnapshot ("ack_queue_enqueue_after", m_nodeId, dest, StateName (m_state),
    m_txPreparationActive, m_txHoldoffOver, m_syncPresent,
    m_ackQueue.size (), m_queue.size (), m_txInProgress,
    m_scheduledTxSlot, m_txCountdownCounter, frame, nullptr, "");
  WriteDifferentialStatisticSample (
    m_nodeId,
    CSR_STAT_MAC_ACK_QUEUE_SIZE,
    static_cast<double> (m_ackQueue.size ()));

  std::cout << "[MAC " << m_nodeId
            << "] Enqueue ACK"
            << " dest=" << dest
            << " seq=" << seq
            << " window=" << (entry.hasWindow ? 1 : 0)
            << " ack_queue_size=" << m_ackQueue.size ()
            << std::endl;

  MaybeScheduleNextTx ();
}

void
CsrMacCore::EnqueueTxFrame (Ptr<Packet> frame,
                            CsrNodeId dest,
                            uint8_t dscp,
                            bool ackable)
{
  CsrAnnotateOpnetEnvelope (frame);

  CsrHeader header;
  if (frame != nullptr && frame->PeekHeader (header) &&
      (header.IsAck () || header.IsDack () ||
       header.GetType () == CSR_PKT_ACK ||
       header.GetType () == CSR_PKT_DACK))
    {
      EnqueueAckFrame (frame, header);
      return;
    }

  // OPNET checks the non-ACK Tx queue limit before DSCP insertion.  A newly
  // arriving high-priority frame is dropped rather than displacing an older
  // lower-priority frame already occupying one of the 512 entries.
  if (m_queue.size () >= TX_QUEUE_SIZE)
    {
      m_dataQueueDropCount++;

      std::cout << "[MAC " << m_nodeId
                << "] Drop TX: OPNET data queue limit reached"
                << " dest=" << dest
                << " dscp=" << unsigned (dscp)
                << " limit=" << TX_QUEUE_SIZE
                << " drops=" << m_dataQueueDropCount
                << std::endl;
      return;
    }

  TxQueueEntry e;
  e.frame   = frame;
  e.dest    = dest;
  e.dscp    = dscp;
  e.ackable = ackable;
  e.enqueuedAt = Simulator::Now ();

  // DSCP priority insert: higher dscp earlier
  auto it = m_queue.begin ();
  for (; it != m_queue.end (); ++it)
    {
      if (dscp > it->dscp)
        {
          break;
        }
    }

  std::cout << "[MAC] Enqueue TX pkt"
            << " dscp=" << int(dscp)
            << " insert_pos=" << std::distance (m_queue.begin (), it)
            << " queue_size_before=" << m_queue.size ()
            << std::endl;

  m_queue.insert (it, e);
  WriteDifferentialStatisticSample (
    m_nodeId,
    CSR_STAT_MAC_TX_QUEUE_SIZE,
    static_cast<double> (m_queue.size ()));
  MaybeScheduleNextTx ();
}

uint32_t
CsrMacCore::CancelAcknowledgedFrames (CsrNodeId neighbor,
                                      uint16_t baseSeq,
                                      uint64_t ackBitmap,
                                      uint64_t dackBitmap)
{
  // DACK is also terminal at MAC: HOP moves that packet to its delayed DACK
  // list, so another queued over-the-air copy must not be transmitted.
  Tranche9MacSnapshot ("mac_cancel_begin", m_nodeId, neighbor, StateName (m_state),
    m_txPreparationActive, m_txHoldoffOver, m_syncPresent,
    m_ackQueue.size (), m_queue.size (), m_txInProgress,
    m_scheduledTxSlot, m_txCountdownCounter, nullptr, nullptr, std::string ("base_sequence=") + CsrTraceInteger (baseSeq));
  uint64_t completedBitmap = ackBitmap | dackBitmap;
  uint32_t removed = 0;

  for (auto it = m_queue.begin (); it != m_queue.end (); )
    {
      if (!it->ackable || it->dest != neighbor || it->frame == nullptr)
        {
          ++it;
          continue;
        }

      CsrHeader queuedHeader;
      if (!it->frame->PeekHeader (queuedHeader))
        {
          ++it;
          continue;
        }

      // OPNET's exact-ACK MAC cleanup compares the outer integer
      // destination.  A routing-control packet with a destination structure
      // is therefore left intact, even after one member of the group ACKs.
      if (queuedHeader.HasDestinationSequences ())
        {
          ++it;
          continue;
        }

      // Unsigned subtraction gives the sequence's age modulo 2^16, matching
      // the 16-bit legacy sequence space even across wraparound.
      uint16_t age = static_cast<uint16_t> (
        baseSeq - queuedHeader.GetSeq ());

      if (age < 64 && (completedBitmap & (1ULL << age)) != 0)
        {
          std::cout << "[MAC " << m_nodeId
                    << "] Cancel queued acknowledged frame"
                    << " neighbor=" << neighbor
                    << " seq=" << queuedHeader.GetSeq ()
                    << " baseSeq=" << baseSeq
                    << " windowIndex=" << age
                    << std::endl;

  Tranche9MacSnapshot ("mac_cancel_frame_before", m_nodeId, neighbor, StateName (m_state),
    m_txPreparationActive, m_txHoldoffOver, m_syncPresent,
    m_ackQueue.size (), m_queue.size (), m_txInProgress,
    m_scheduledTxSlot, m_txCountdownCounter, it->frame, nullptr, "");
          it = m_queue.erase (it);
  Tranche9MacSnapshot ("mac_cancel_frame_after", m_nodeId, neighbor, StateName (m_state),
    m_txPreparationActive, m_txHoldoffOver, m_syncPresent,
    m_ackQueue.size (), m_queue.size (), m_txInProgress,
    m_scheduledTxSlot, m_txCountdownCounter, nullptr, nullptr, "");
          removed++;
          continue;
        }

      ++it;
    }

  Tranche9MacSnapshot ("mac_cancel_end", m_nodeId, neighbor, StateName (m_state),
    m_txPreparationActive, m_txHoldoffOver, m_syncPresent,
    m_ackQueue.size (), m_queue.size (), m_txInProgress,
    m_scheduledTxSlot, m_txCountdownCounter, nullptr, nullptr, std::string ("removed=") + CsrTraceInteger (removed));
  return removed;
}

uint32_t
CsrMacCore::CancelQueuedFramesByType (CsrNodeId neighbor, uint8_t type)
{
  uint32_t removed = 0;

  for (auto it = m_queue.begin (); it != m_queue.end (); )
    {
      CsrHeader header;
      if (it->dest == neighbor &&
          it->frame != nullptr &&
          it->frame->PeekHeader (header) &&
          header.GetType () == type)
        {
          it = m_queue.erase (it);
          removed++;
          continue;
        }

      ++it;
    }

  if (removed > 0)
    {
      std::cout << "[MAC " << m_nodeId
                << "] Replace immediate-tag frame"
                << " neighbor=" << neighbor
                << " type=" << unsigned (type)
                << " removed=" << removed
                << std::endl;
    }

  return removed;
}

void
CsrMacCore::MaybeScheduleNextTx ()
{
  Tranche9MacSnapshot ("mac_schedule_request", m_nodeId, 0, StateName (m_state),
    m_txPreparationActive, m_txHoldoffOver, m_syncPresent,
    m_ackQueue.size (), m_queue.size (), m_txInProgress,
    m_scheduledTxSlot, m_txCountdownCounter, nullptr, nullptr, "");
  if (m_dev == nullptr)
    {
      return;
    }

  if (!HasPendingFrame ())
    {
      return;
    }

  // A frame queued during Tx is picked up by FinishTx().  OPNET returns to
  // Search before resuming the already-cleared holdoff/countdown process.
  if (m_txInProgress)
    {
      return;
    }

  if (m_state == State::IDLE)
    {
      // Idle's enter executive schedules an untracked RTS TSLOT on the next
      // simulation-wide 13-ms boundary, unless that boundary is too close to
      // the periodic WAKE.  HOP_PK_RCVD itself only queues the frame.
      ScheduleIdleRts ();
      return;
    }
  if (!m_slotTickEnabled)
    {
      // Direct-device tests begin in Search rather than passing through the
      // OPNET Idle -> Search transition.  Initialize the same independent
      // slot and holdoff timers on their first transmit request.
      StartSearchTiming ();
    }

  if (!m_txHoldoffOver && !m_txHoldoffEvent.IsPending ())
    {
      StartTxHoldoff ();
    }

  // Search-state arrivals are activated by the next shared TSLOT, after its
  // reservation advancement, matching tslot_tasks() ordering.
}

void
CsrMacCore::StartSearchTiming ()
{
  if (!m_slotTickEnabled)
    {
      StartSlotTick (m_slotTickPeriod);
    }
  StartTxHoldoff ();
}

void
CsrMacCore::ScheduleIdleRts ()
{
  if (m_state != State::IDLE ||
      !HasPendingFrame () ||
      m_idleRtsEvent.IsPending ())
    {
      return;
    }

  int64_t nowSteps = Simulator::Now ().GetTimeStep ();
  int64_t periodSteps = m_slotTickPeriod.GetTimeStep ();
  NS_ABORT_MSG_IF (periodSteps <= 0,
                   "CSR MAC slot period must be positive");
  Time nextSlot = TimeStep (
    (nowSteps / periodSteps + 1) * periodSteps);

  bool deferToWake = false;
  if (m_dev != nullptr && m_dev->IsDutyCyclingEnabled ())
    {
      double nextWakeSec = m_dev->GetNextPeriodicWake (
        Simulator::Now ().GetSeconds ());
      deferToWake = std::fabs (nextWakeSec - nextSlot.GetSeconds ()) <=
        m_slotTickPeriod.GetSeconds () / 2.0;
    }

  if (deferToWake)
    {
  Tranche9MacSnapshot ("mac_idle_rts_defer", m_nodeId, 0, StateName (m_state),
    m_txPreparationActive, m_txHoldoffOver, m_syncPresent,
    m_ackQueue.size (), m_queue.size (), m_txInProgress,
    m_scheduledTxSlot, m_txCountdownCounter, nullptr, nullptr, "");
      m_dev->SchedulePendingTxWake ();
      return;
    }

  std::cout << "[MAC " << m_nodeId
            << "] Idle queue schedules RTS TSLOT at "
            << nextSlot.GetSeconds ()
            << std::endl;
  Tranche9MacSnapshot ("mac_idle_rts_schedule", m_nodeId, 0, StateName (m_state),
    m_txPreparationActive, m_txHoldoffOver, m_syncPresent,
    m_ackQueue.size (), m_queue.size (), m_txInProgress,
    m_scheduledTxSlot, m_txCountdownCounter, nullptr, nullptr, std::string ("due_s=") + CsrTraceDouble (nextSlot.GetSeconds ()));
  m_idleRtsEvent = Simulator::Schedule (
    nextSlot - Simulator::Now (),
    &CsrMacCore::IdleRts,
    this);
}

void
CsrMacCore::IdleRts ()
{
  if (m_state != State::IDLE || !HasPendingFrame ())
    {
      return;
    }

  // Idle --RTS--> Search runs prep_tx(): restart the relative slot timer and
  // independent holdoff, enable PREP_TX immediately, and redraw <= 0.
  SetReceiveState (State::SEARCH);
  ActivateTxPreparation (true);
}

void
CsrMacCore::StartTxHoldoff ()
{
  Tranche9MacSnapshot ("mac_holdoff_schedule_before", m_nodeId, 0, StateName (m_state),
    m_txPreparationActive, m_txHoldoffOver, m_syncPresent,
    m_ackQueue.size (), m_queue.size (), m_txInProgress,
    m_scheduledTxSlot, m_txCountdownCounter, nullptr, nullptr, std::string ("delay_s=") + CsrTraceDouble (TS_HOLDOFF_SECONDS));
  if (m_txHoldoffEvent.IsPending ())
    {
      Simulator::Cancel (m_txHoldoffEvent);
    }

  m_txHoldoffOver = false;
  m_txHoldoffEvent = Simulator::Schedule (
    Seconds (TS_HOLDOFF_SECONDS),
    &CsrMacCore::TxHoldoffExpired,
    this);
}

void
CsrMacCore::TxHoldoffExpired ()
{
  m_txHoldoffOver = true;

  CsrDifferentialTraceEvent event;
  event.event = "reservation_holdoff";
  event.node = CsrTraceInteger (m_nodeId);
  if (m_scheduledTxSlot >= 0)
    {
      event.reservationSlot = CsrTraceSignedInteger (m_scheduledTxSlot);
    }
  if (m_txCountdownCounter >= -1)
    {
      event.reservationCounter = CsrTraceSignedInteger (
        m_txCountdownCounter);
    }
  WriteDifferentialTrace (event);
  Tranche9MacSnapshot ("mac_holdoff_expired", m_nodeId, 0, StateName (m_state),
    m_txPreparationActive, m_txHoldoffOver, m_syncPresent,
    m_ackQueue.size (), m_queue.size (), m_txInProgress,
    m_scheduledTxSlot, m_txCountdownCounter, nullptr, nullptr, "");

  std::cout << "[MAC " << m_nodeId
            << "] OPNET 300-ms transmit holdoff complete"
            << std::endl;
}

void
CsrMacCore::ActivateTxPreparation (bool redrawZero,
                                   bool cancelPostTxWait)
{
  if (m_txPreparationActive || !HasPendingFrame ())
    {
      return;
    }

  if (cancelPostTxWait && m_dev != nullptr)
    {
      // tslot_tasks() cancels an outstanding post-Tx wait when queued work
      // turns PREP_TX back on.
      m_dev->CancelPostTxWait ();
    }
  m_txPreparationActive = true;

  bool selectedNewSlot = m_txCountdownCounter < 0 ||
                         (redrawZero && m_txCountdownCounter == 0);
  if (selectedNewSlot)
    {
      CsrNodeId dest = !m_ackQueue.empty ()
        ? m_ackQueue.front ().dest
        : m_queue.front ().dest;
      m_scheduledTxSlot = PickTxSlot (dest);
      m_txCountdownCounter = m_scheduledTxSlot;

      std::cout << "[MAC " << m_nodeId
                << "] starts Pre-Tx with new slot="
                << m_scheduledTxSlot
                << " holdoff_over=" << (m_txHoldoffOver ? 1 : 0)
                << std::endl;
    }
  else
    {
      std::cout << "[MAC " << m_nodeId
                << "] resumes Pre-Tx with live slot="
                << m_scheduledTxSlot
                << " counter=" << m_txCountdownCounter
                << std::endl;
    }

  if (m_forcedReservationSlot > 0)
    {
      m_scheduledTxSlot = m_forcedReservationSlot;
      m_txCountdownCounter = m_forcedReservationSlot;
      selectedNewSlot = true;

      // Nodes in the recovered scenario have independent 13-ms timer phases.
      // Put controlled differential runs on a common future epoch so neither
      // sender hears the other's preamble before its final countdown event.
      Time epoch = Seconds (0.1);
      double holdoffGuard = m_txHoldoffOver ? 0.0 : TS_HOLDOFF_SECONDS;
      Time earliest = Simulator::Now () +
        Seconds (holdoffGuard) + m_slotTickPeriod;
      int64_t epochSteps = epoch.GetTimeStep ();
      int64_t earliestSteps = earliest.GetTimeStep ();
      int64_t alignedSteps =
        ((earliestSteps + epochSteps - 1) / epochSteps) * epochSteps;
      if (m_slotTickEvent.IsPending ())
        {
          Simulator::Cancel (m_slotTickEvent);
        }
      m_slotTickEnabled = true;
      m_slotTickEvent = Simulator::Schedule (
        TimeStep (alignedSteps - Simulator::Now ().GetTimeStep ()),
        &CsrMacCore::SlotTick,
        this);
    }

  CsrDifferentialTraceEvent event;
  event.event = "reservation_prepare";
  event.node = CsrTraceInteger (m_nodeId);
  event.reservationSlot = CsrTraceSignedInteger (m_scheduledTxSlot);
  event.reservationCounter = CsrTraceSignedInteger (
    m_txCountdownCounter);
  event.reason = m_forcedReservationSlot > 0
    ? (m_txHoldoffOver ? "controlled_ready" : "controlled_wait")
    : (selectedNewSlot ? "new" : "reuse");
  WriteDifferentialTrace (event);
  Tranche9MacSnapshot ("mac_prepare_after", m_nodeId, 0, StateName (m_state),
    m_txPreparationActive, m_txHoldoffOver, m_syncPresent,
    m_ackQueue.size (), m_queue.size (), m_txInProgress,
    m_scheduledTxSlot, m_txCountdownCounter, nullptr, nullptr, event.reason);
}

void
CsrMacCore::NotifyPhyTxStart (Time duration)
{
  if (m_dev != nullptr)
    {
      // send_pk() cancels a previous post-Tx wait when a new transmission
      // actually starts, including a direct-device transmission.
      m_dev->CancelPostTxWait ();
    }
  m_txInProgress = true;
  m_state = State::TX;

  CsrDifferentialTraceEvent event;
  event.event = "mac_state";
  event.node = CsrTraceInteger (m_nodeId);
  event.detail = StateName (State::TX);
  WriteDifferentialTrace (event);

  if (m_finishTxEvent.IsPending ())
    {
      Simulator::Cancel (m_finishTxEvent);
    }
  m_finishTxEvent = Simulator::Schedule (duration,
                                         &CsrMacCore::FinishTx,
                                         this);
}

void
CsrMacCore::FinishTx ()
{
  m_txInProgress = false;
  m_state = State::SEARCH;

  CsrDifferentialTraceEvent event;
  event.event = "mac_state";
  event.node = CsrTraceInteger (m_nodeId);
  event.detail = StateName (State::SEARCH);
  WriteDifferentialTrace (event);

  if (HasPendingFrame ())
    {
      // post_tx() enables PREP_TX immediately for frames that arrived or
      // remained during Tx, reusing the slot advertised by this frame.
      ActivateTxPreparation ();
    }

  if (m_dev != nullptr)
    {
      // Source post_tx() starts WAIT_FOR_ACK only after DONE_TX and only when
      // both ACK and data queues are empty.
      m_dev->OnMacTxFinished (!HasPendingFrame ());
    }
}

int
CsrMacCore::ChooseRateForDest (CsrNodeId dest)
{
  auto it = m_neighbors.find (dest);
  double pl = 90.0;
  if (it != m_neighbors.end ())
    {
      pl = it->second.lastPathlossDb;
    }

  if      (pl > 120.0) return 8;
  else if (pl > 100.0) return 16;
  else if (pl > 80.0)  return 32;
  else if (pl > 60.0)  return 64;
  else                 return 128;
}

PreambleType
CsrMacCore::ChoosePreambleForDest (CsrNodeId dest)
{
  auto it = m_neighbors.find (dest);

  if (it == m_neighbors.end ())
    {
      return PREAMBLE_LONG;
    }

  double lastHeard = it->second.lastHeardSec;
  double now       = Simulator::Now ().GetSeconds ();

  // OPNET chooses the preamble from neighbor freshness even when duty
  // cycling is enabled.  It uses the current local active_nodes value here,
  // not max_reported_active_nodes (the latter only expands slot selection).
  // This is the same expression as br_mac's POST_TX_WAIT_TIME macro.
  double threshold =
    15.0 + 1.5 * static_cast<double> (m_activeNodesForPostTx) + 0.5;

  if (lastHeard < 0.0 || (now - lastHeard) > threshold)
    {
      return PREAMBLE_LONG;
    }
  else
    {
      return PREAMBLE_SHORT;
    }
}

int
CsrMacCore::SelectQueuedFrameRate (Ptr<Packet> frame,
                                   CsrNodeId dest,
                                   bool ackable) const
{
  CsrHeader header;
  if (frame != nullptr && frame->PeekHeader (header))
    {
      if (header.HasLinkControl ())
        {
          switch (header.GetSpeedKey ())
            {
            case 8:
            case 16:
            case 32:
            case 64:
            case 128:
            case 500:
            case 1000:
              return header.GetSpeedKey ();
            default:
              return 8;
            }
        }

      if (!ackable)
        {
          return 8;
        }

      int selectedRate = m_maxRateKbps;
      for (CsrNodeId target : header.EnumerateDestinations ())
        {
          selectedRate = std::min (
            selectedRate,
            SelectRateByPerTarget (
              target,
              CsrGetOpnetWireSize (frame) * 8,
              0.50));
        }
      return selectedRate;
    }

  if (!ackable)
    {
      return 8;
    }

  return SelectRateByPerTarget (dest,
                                CsrGetOpnetWireSize (frame) * 8,
                                0.50);
}

double
CsrMacCore::SelectQueuedFrameTxPower (Ptr<Packet> frame) const
{
  CsrHeader header;
  if (frame != nullptr && frame->PeekHeader (header) &&
      header.HasLinkControl ())
    {
      return header.GetTxPowerDbm ();
    }

  return m_dev == nullptr
    ? 0.0
    : m_dev->GetPhy ().profile.txPowerDbm;
}

uint32_t
CsrMacCore::GetConcatByteLimit (int rateKbps) const
{
  switch (rateKbps)
    {
    case 8:   return 256;
    case 16:  return 512;
    case 32:  return 1024;
    case 64:  return 2048;
    case 128: return 4096;
    default:  return 0;
    }
}

bool
CsrMacCore::FitsConcatFrame (Ptr<Packet> frame,
                             int frameRateKbps,
                             uint32_t byteCount,
                             int currentRateKbps) const
{
  int aggregateRate = std::min (frameRateKbps, currentRateKbps);
  uint32_t limit = GetConcatByteLimit (aggregateRate);
  if (limit == 0)
    {
      // The source material does not provide high-rate concatenation limits.
      // Transmit the queue head alone instead of inventing a capacity or
      // repeatedly rescheduling an otherwise valid high-rate frame.
      return byteCount == 0;
    }
  return byteCount + CsrGetOpnetWireSize (frame) < limit;
}

PreambleType
CsrMacCore::SelectAggregatePreamble (
  const std::vector<SelectedTxFrame> &selected,
  bool concatenating)
{
  // Preserve a legacy limitation: outside the concatenation branch OPNET
  // reads only the packet's scalar/primary destination, even when the packet
  // also contains a destination structure.
  if (!concatenating)
    {
      return ChoosePreambleForDest (selected.front ().dest);
    }

  // Preserve the supplied send_pk() walk and its observable variable reuse.
  // ACKs are already before DATA in selected, and structured destinations are
  // visited in stored order.  An unknown destination resets time0 to now; a
  // later known destination may lower it again.  Only the final ngbr_ptr
  // value causes the unconditional-long branch, so this is deliberately not
  // the order-independent "any unknown means LONG" policy.
  double now = Simulator::Now ().GetSeconds ();
  double time0 = now;
  bool finalDestinationKnown = false;
  for (const auto &entry : selected)
    {
      CsrHeader header;
      if (entry.frame != nullptr && entry.frame->PeekHeader (header))
        {
          for (CsrNodeId destination : header.EnumerateDestinations ())
            {
              auto neighbor = m_neighbors.find (destination);
              finalDestinationKnown = neighbor != m_neighbors.end ();
              if (!finalDestinationKnown)
                {
                  time0 = now;
                }
              else if (neighbor->second.lastHeardSec < time0)
                {
                  time0 = neighbor->second.lastHeardSec;
                }
            }
        }
      else
        {
          auto neighbor = m_neighbors.find (entry.dest);
          finalDestinationKnown = neighbor != m_neighbors.end ();
          if (!finalDestinationKnown)
            {
              time0 = now;
            }
          else if (neighbor->second.lastHeardSec < time0)
            {
              time0 = neighbor->second.lastHeardSec;
            }
        }
    }

  if (!finalDestinationKnown)
    {
      return PREAMBLE_LONG;
    }

  double freshnessSeconds =
    15.0 + 1.5 * static_cast<double> (m_activeNodesForPostTx) + 0.5;
  return now - time0 > freshnessSeconds
    ? PREAMBLE_LONG
    : PREAMBLE_SHORT;
}

void
CsrMacCore::DoTx ()
{
  if (!HasPendingFrame () || m_dev == nullptr)
    {
      m_txPreparationActive = false;
      return;
    }

  // A delayed concatenation retry must re-enter through the same MAC gates
  // as an ordinary slot opportunity.  If state changed while the retry was
  // pending, retain PREP_TX/counter=-1 and let a later eligible SlotTick try
  // again instead of transmitting in Idle, Track, Tx, or under SYNC/holdoff.
  if (m_txInProgress ||
      m_state != State::SEARCH ||
      m_syncPresent ||
      !m_txHoldoffOver ||
      !m_txPreparationActive ||
      m_txCountdownCounter != -1)
    {
      return;
    }

  std::vector<SelectedTxFrame> selected;
  uint32_t byteCount = 0;
  int aggregateRateKbps = 1000;
  bool packingStopped = false;
  bool concatenate = m_ackQueue.size () + m_queue.size () > 1;

  if (concatenate)
    {
      // OPNET scans the ACK queue first and stops at the first entry that
      // cannot fit at the slowest rate selected so far.
      for (uint32_t i = 0;
           i < m_ackQueue.size () && !packingStopped;
           ++i)
        {
          const AckQueueEntry &entry = m_ackQueue[i];
          int rate = SelectQueuedFrameRate (entry.frame,
                                            entry.dest,
                                            false);
          if (!FitsConcatFrame (entry.frame,
                                rate,
                                byteCount,
                                aggregateRateKbps))
            {
              packingStopped = true;
              break;
            }

          aggregateRateKbps = std::min (aggregateRateKbps, rate);
          byteCount += CsrGetOpnetWireSize (entry.frame);
          selected.push_back ({entry.frame->Copy (),
                               entry.dest,
                               false,
                               true,
                               0,
                               i,
                               rate,
                               SelectQueuedFrameTxPower (entry.frame)});
        }

      // Data is removed strictly from the priority queue head.  A non-fitting
      // head blocks every later entry, exactly as in the legacy segmentation
      // loop.  The 16-segment stop is checked only after adding data.
      for (uint32_t i = 0;
           i < m_queue.size () && !packingStopped;
           ++i)
        {
          const TxQueueEntry &entry = m_queue[i];
          int rate = SelectQueuedFrameRate (entry.frame,
                                            entry.dest,
                                            entry.ackable);
          if (!FitsConcatFrame (entry.frame,
                                rate,
                                byteCount,
                                aggregateRateKbps))
            {
              packingStopped = true;
              break;
            }

          aggregateRateKbps = std::min (aggregateRateKbps, rate);
          byteCount += CsrGetOpnetWireSize (entry.frame);
          selected.push_back ({entry.frame->Copy (),
                               entry.dest,
                               entry.ackable,
                               false,
                               entry.dscp,
                               i,
                               rate,
                               SelectQueuedFrameTxPower (entry.frame)});

          // OPNET removes each accepted data segment while building the
          // aggregate and writes size before delay.  The ns-3 queue remains
          // intact until the already-copied aggregate has entered the PHY,
          // but these observation-only samples retain that source order.
          WriteDifferentialStatisticSample (
            m_nodeId,
            CSR_STAT_MAC_TX_QUEUE_SIZE,
            static_cast<double> (m_queue.size () - i - 1));
          WriteDifferentialStatisticSample (
            m_nodeId,
            CSR_STAT_MAC_TX_QUEUE_DELAY,
            (Simulator::Now () - entry.enqueuedAt).GetSeconds ());

          if (selected.size () >= MAX_CONCAT_SEGMENTS)
            {
              packingStopped = true;
            }
        }
    }
  else if (!m_ackQueue.empty ())
    {
      const AckQueueEntry &entry = m_ackQueue.front ();
      aggregateRateKbps = SelectQueuedFrameRate (entry.frame,
                                                  entry.dest,
                                                  false);
      byteCount = CsrGetOpnetWireSize (entry.frame);
      selected.push_back ({entry.frame->Copy (),
                           entry.dest,
                           false,
                           true,
                           0,
                           0,
                           aggregateRateKbps,
                           SelectQueuedFrameTxPower (entry.frame)});
    }
  else
    {
      const TxQueueEntry &entry = m_queue.front ();
      aggregateRateKbps = SelectQueuedFrameRate (entry.frame,
                                                  entry.dest,
                                                  entry.ackable);
      byteCount = CsrGetOpnetWireSize (entry.frame);
      selected.push_back ({entry.frame->Copy (),
                           entry.dest,
                           entry.ackable,
                           false,
                           entry.dscp,
                           0,
                           aggregateRateKbps,
                           SelectQueuedFrameTxPower (entry.frame)});
      WriteDifferentialStatisticSample (
        m_nodeId,
        CSR_STAT_MAC_TX_QUEUE_SIZE,
        static_cast<double> (m_queue.size () - 1));
      WriteDifferentialStatisticSample (
        m_nodeId,
        CSR_STAT_MAC_TX_QUEUE_DELAY,
        (Simulator::Now () - entry.enqueuedAt).GetSeconds ());
    }

  if (selected.empty ())
    {
      std::cout << "[MAC " << m_nodeId
                << "] OPNET concatenation could not fit queue head"
                << std::endl;
      m_txEvent = Simulator::Schedule (Seconds (1.0),
                                       &CsrMacCore::MaybeScheduleNextTx,
                                       this);
      return;
    }

  // Predict the post-packing ACK removals for source-ordered observation.
  // Physical mutation remains after SendFramesToPeers(), preserving existing
  // ns-3 behavior while the trace matches br_mac's pre-transmitter writes.
  std::vector<uint32_t> selectedAckTransmissions (m_ackQueue.size (), 0);
  for (const auto &entry : selected)
    {
      if (entry.fromAckQueue)
        {
          selectedAckTransmissions[entry.queueIndex]++;
        }
    }
  uint32_t observedAckQueueSize = m_ackQueue.size ();
  for (uint32_t i = 0; i < m_ackQueue.size (); ++i)
    {
      if (m_ackQueue[i].txCount + selectedAckTransmissions[i] >=
          MAX_ACK_RESEND + 1)
        {
          observedAckQueueSize--;
          WriteDifferentialStatisticSample (
            m_nodeId,
            CSR_STAT_MAC_ACK_QUEUE_SIZE,
            static_cast<double> (observedAckQueueSize));
        }
    }

  CsrNodeId dest = selected.front ().dest;

  // The br_OTA DSCP field is metadata: it is the maximum across DATA
  // segments only.  ACK queue entries are packed first but do not contribute.
  m_lastAggregateDscp = 0;
  for (const auto &entry : selected)
    {
      if (!entry.fromAckQueue)
        {
          m_lastAggregateDscp = std::max (m_lastAggregateDscp, entry.dscp);
        }
    }

  int powerSelectionRateKbps = selected.front ().rateKbps;
  double aggregateTxPowerDbm = selected.front ().txPowerDbm;

  for (uint32_t i = 1; i < selected.size (); ++i)
    {
      const SelectedTxFrame &entry = selected[i];
      if (entry.rateKbps < powerSelectionRateKbps)
        {
          powerSelectionRateKbps = entry.rateKbps;
          aggregateTxPowerDbm = entry.txPowerDbm;
        }
      else if (entry.rateKbps == powerSelectionRateKbps)
        {
          aggregateTxPowerDbm = std::max (aggregateTxPowerDbm,
                                          entry.txPowerDbm);
        }
    }

  std::vector<Ptr<Packet>> wireFrames;
  wireFrames.reserve (selected.size ());
  bool anyAckable = false;
  PreambleType pt = SelectAggregatePreamble (selected, concatenate);

  for (auto &entry : selected)
    {
      CsrHeader header;
      entry.frame->RemoveHeader (header);
      if (header.HasLinkControl ())
        {
          header.SetLinkControl (
            static_cast<CsrRateKey> (aggregateRateKbps),
            aggregateTxPowerDbm,
            header.GetRxPowerDbm ());
        }
      else
        {
          header.SetSpeedKey (aggregateRateKbps);
        }
      if (header.GetType () == CSR_PKT_DATA ||
          header.GetType () == CSR_PKT_ACK ||
          header.GetType () == CSR_PKT_DACK)
        {
          header.SetType (header.IsAck ()
                            ? CSR_PKT_ACK
                            : (header.IsDack ()
                                 ? CSR_PKT_DACK
                                 : CSR_PKT_DATA));
        }
      header.SetDestType (
        header.HasDestinationSequences ()
          ? CSR_DEST_MULTICAST
          : (entry.dest == CSR_BROADCAST_ID
               ? CSR_DEST_BROADCAST
               : CSR_DEST_UNICAST));
      entry.frame->AddHeader (header);
      wireFrames.push_back (entry.frame);
      anyAckable = anyAckable || entry.ackable;
    }

  if (pt == PREAMBLE_LONG)
    {
      m_longPreambleTxCount++;
    }
  else
    {
      m_shortPreambleTxCount++;
    }

  // OPNET includes a newly selected future reservation in every OTA frame.
  // The sender loads that same value into its persistent txslot_counter even
  // if this transmission drains both queues.
  m_lastTxOpportunitySlot = m_scheduledTxSlot;
  int nextReservedSlot = PickTxSlot (dest);
  m_lastAdvertisedReservationSlot = nextReservedSlot;
  m_scheduledTxSlot = nextReservedSlot;
  m_txCountdownCounter = nextReservedSlot;
  m_txPreparationActive = false;

  CsrDifferentialTraceEvent reservationEvent;
  reservationEvent.event = "reservation_advertise";
  reservationEvent.node = CsrTraceInteger (m_nodeId);
  reservationEvent.reservationSlot = CsrTraceSignedInteger (
    nextReservedSlot);
  reservationEvent.reservationCounter = CsrTraceSignedInteger (
    m_txCountdownCounter);
  WriteDifferentialTrace (reservationEvent);

  // Send via device
  std::cout << "[MAC " << m_nodeId
            << "] TX opportunity reached"
            << " currentSlot=" << m_lastTxOpportunitySlot
            << " reserveNextSlot=" << nextReservedSlot
            << std::endl;

  m_dev->SendFramesToPeers (wireFrames,
                            aggregateRateKbps,
                            aggregateTxPowerDbm,
                            pt,
                            nextReservedSlot,
                            anyAckable);

  m_lastTxRateKbps = aggregateRateKbps;
  m_lastTxPowerDbm = aggregateTxPowerDbm;

  m_transmittedFrameCount++;

  // OPNET br_mac sends br_Mac_Hop_Inst only after the frame actually enters
  // the transmitter.  HOP uses that sent instant, rather than its enqueue
  // time, as the origin for ACK timeout and retransmission processing.
  if (!m_txSentCallback.IsNull ())
    {
      for (const auto &entry : selected)
        {
          if (!entry.ackable)
            {
              continue;
            }
          CsrHeader header;
          entry.frame->PeekHeader (header);
          m_txSentCallback (entry.dest,
                            header.GetSeq (),
                            Simulator::Now ());
        }
    }

  uint32_t selectedAckCount = 0;
  uint32_t selectedDataCount = 0;
  for (const auto &entry : selected)
    {
      if (entry.fromAckQueue)
        {
          AckQueueEntry &ackEntry = m_ackQueue[entry.queueIndex];
          ackEntry.txCount++;
          selectedAckCount++;
          std::cout << "[MAC " << m_nodeId
                    << "] ACK transmitted in aggregate"
                    << " dest=" << ackEntry.dest
                    << " seq=" << ackEntry.seq
                    << " txCount=" << ackEntry.txCount
                    << "/" << (MAX_ACK_RESEND + 1)
                    << std::endl;
        }
      else
        {
          selectedDataCount++;
        }
    }

  for (auto it = m_ackQueue.begin (); it != m_ackQueue.end (); )
    {
      if (it->txCount < MAX_ACK_RESEND + 1)
        {
          ++it;
          continue;
        }
      std::cout << "[MAC " << m_nodeId
                << "] Remove ACK after OPNET resend limit"
                << " dest=" << it->dest
                << " seq=" << it->seq
                << std::endl;
      it = m_ackQueue.erase (it);
    }

  if (selectedDataCount > 0)
    {
      m_queue.erase (m_queue.begin (),
                     m_queue.begin () + selectedDataCount);
    }

  std::cout << "[MAC " << m_nodeId
            << "] OPNET aggregate transmitted"
            << " segments=" << selected.size ()
            << " ackSegments=" << selectedAckCount
            << " dataSegments=" << selectedDataCount
            << " bytes=" << byteCount
            << " rate=" << aggregateRateKbps
            << std::endl;

  // FinishTx() re-enables PREP_TX if another frame remains.  Otherwise the
  // advertised counter continues to advance in Search with PREP_TX false,
  // exactly as br_mac.tslot_tasks() requires for reservation reuse.
}



// ------------------------------------------------------------
// CsrHopLayer: simplified hop layer
// ------------------------------------------------------------
