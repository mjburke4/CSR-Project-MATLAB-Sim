#!/usr/bin/env python3
"""Finalize the independent T22 preparation gate; never assert MATLAB execution."""
import hashlib,json,sys
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path('csr22').resolve();REVIEW=Path('t22-work/review')
sys.path.insert(0,str(ROOT/'scripts'));sys.path.insert(0,str(REVIEW.resolve()))
import analyze_tranche22_return as checker
from audit_baseline import audit as audit_baseline
from audit_contract_inputs import audit as audit_contract

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(ok,message):
 if not ok:raise ValueError(message)
def main():
 candidate=ROOT/'evidence/tranche-22-candidate.json'
 check(sha(candidate)=='333686e6ee7822baf9f53ad06a0aa1d6475fced46947281596704ff147b5ba06','Frozen candidate changed after review request')
 prepared=checker.verify_preparation(ROOT)
 baseline=audit_baseline(ROOT);contract=audit_contract(ROOT)
 check(baseline['passed'] and contract['passed'],'Baseline or contract provenance failed')
 native=json.loads((REVIEW/'native-review.json').read_text())
 check(native['passed'] and not native['remaining_blockers'],'Native independent review failed')
 for name,digest in native['bindings'].items():check(sha(ROOT/name)==digest,'Native binding changed: '+name)
 static_path=ROOT/'evidence/tranche-22-preparation/matlab-static.json';static=json.loads(static_path.read_text())
 check(static['exit_code']==0 and static['matlab_executed'] is False,'Static analysis failed or mislabeled')
 for name,digest in static['files'].items():check(sha(ROOT/name)==digest,'Static analysis input changed: '+name)
 integration=Path('t22-work/checker-integration/unittest.log');log=integration.read_text()
 check('Ran 51 tests' in log and '\nOK\n' in log and 'skipped=' not in log,'Full checker integration suite did not pass')
 check(prepared['planned_matlab_tests']==89 and prepared['planned_cases']==9 and prepared['planned_checkpoints']==364,'Planned membership changed')
 reviewed={**prepared['source'],**{name:row['sha256'] for name,row in prepared['references'].items()}}
 record={'schema':'csr-tranche22-independent-final-review-v1','reviewed_utc':datetime.now(timezone.utc).isoformat(),'passed':True,'status':'preparation_gate_passed_matlab_execution_pending','remaining_blockers':[],'candidate_sha256':sha(candidate),'scope':'Source, inputs, native execution, Python return checker and handoff preparation. Clean overlay packaging is a separate final check.','production_source_unchanged':True,'accepted_source_bindings_unchanged':376,'accepted_matlab_files_unchanged':175,'accepted_reference_bindings_unchanged':98,'candidate_source_bindings':len(prepared['source']),'candidate_reference_bindings':len(prepared['references']),'native_executed':True,'native_cases':9,'native_checkpoints':364,'native_raw_events':968,'independent_integer_milestone_assertions':142,'checker_tests_passed':51,'checker_tests_skipped':0,'checker_integration_scope':'Synthetic parser fixture; native reference rows copied only to exercise all evidence-verification layers. This is not MATLAB runtime evidence.','matlab_files_statically_checked':3,'matlab_executed':False,'new_matlab_tests_executed':0,'planned_matlab_tests':89,'matlab_cross_engine_acceptance_pending':True,'full_campus_simulation_executed':False,'numerical_parity_established':False,'working_campus_band_percent':10,'discrete_state_tolerance':0,'action_timestamp_tolerance_seconds':1e-9,'resolved_findings':['Exact failed-row index vector handled in Python return checker.','Canonical native reference path synchronized.','Action timestamp tolerance synchronized.','Native library build interruptions repaired; actual linked ELF hashes, raw execution and five build attempt receipts verified.','Failure packaging preserves main replay evidence even when a focused test fails.'],'limitations':['Native actual callbacks tested; MATLAB runtime validation must occur on owner machine.','Controlled HOP callbacks exclude PHY, random stream, network workload and end-to-end wire security equivalence.','Existing actual-tx/native provisional queued-retry distinction remains unchanged.','No natural timer-boundary tie or sub-TIC DACK coalescence coverage is claimed.','Seed-130 motif is reduced and transformed, not a complete historical campus replay.','Matching controlled callbacks would not alone establish the origin of the stochastic full-campus gaps.'],'reviewed_artifact_sha256':{str(p):sha(p) for p in [REVIEW/'baseline-review.json',REVIEW/'contract-input-review.json',REVIEW/'design-review.json',REVIEW/'native-review.json',static_path,integration]},'reviewed_script_sha256':{str(p):sha(p) for p in sorted(REVIEW.glob('*.py'))},'reviewed_source_and_reference_sha256':dict(sorted(reviewed.items()))}
 (REVIEW/'final-review.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({k:record[k] for k in ['passed','status','candidate_sha256','candidate_source_bindings','candidate_reference_bindings','native_cases','native_checkpoints','checker_tests_passed','planned_matlab_tests','matlab_executed']}))
if __name__=='__main__':main()
