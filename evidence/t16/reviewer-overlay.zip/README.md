# Tranche 16 reviewer overlay

This package repairs two Python evidence-review defects while preserving the exact issued Tranche 16 source tree and owner MATLAB evidence. It contains 37 self-contained reviewer modules, with changes in only `analyze_tranche11_return.py` and `analyze_tranche16_return.py`.

The full review completed successfully against the original candidate. The owner's MATLAB run passed 129 focused tests and 192 structural checks across 12 real-PHY cases. No MATLAB execution was performed by this reviewer. This result does not establish full-network acceptance or numerical parity.

## Reproduce

Provide the exact issued T16 source tree and the owner's T16 evidence ZIP. The source tree must retain all issued source and reference artifacts; the review verifies their membership, hashes and sizes.

```bash
python -B run_tests.py --source-root /path/to/exact/csr16 --output reproduced-tests.json
python -B run_review.py --source-root /path/to/exact/csr16 --evidence /path/to/t16.zip --output reproduced-review
```

`run_review.py` verifies `overlay-manifest.json` before importing the repaired modules. It applies no patch to the source tree. `run_tests.py` runs 28 repair regressions plus the 69 original T11/T16 reviewer tests against the same overlay. An expected negative T11 test prints a rejection line; the unittest and JSON outcomes determine whether the suite passed.

Do not apply `reviewer-fixes.patch` to the frozen issued source used for reviewing the owner's run: that would invalidate its legitimate source snapshot. The patch records the exact differences for future development or an independently copied tree. The external overlay is the reproduction mechanism for this owner return.

## Preserved identity and scope

- Upstream ns-3 source pin: `486d9e01f010fdfd4c6aebb87c6d7e51fc674a5b`.
- Issued MATLAB candidate SHA256: `f22a893457fd7927342ed7fa176c1e227d387f6a6be3631fd0204f9a53bc1a36`.
- Owner source snapshot SHA256: `90b5506f4fdb54f64ae7dac61c0e48df9da2253a8408a4b50b3ad30309ac1905`.
- Owner ZIP SHA256: `4fbfb17ba654bee0a137f1fc2d3ac3f65a091bf936d6c44589b1db9db1f4be60`.
- Corrected review: `return/review.json`.
- Disposition and remaining milestone: `REPORT.md` and `REPORT.json`.
- Original failed review reports: `original-review-failed.json` and `reference-only-review-failed.json`.

The file-only reference repair retains the exact membership, duplicate/path safety, stability, hash and size checks. The aggregate repair allows only four-ULP endpoint serialization differences on the declared grid, requires all bins in all core series, and leaves values and missing samples intact.

All six timing-policy pairs retain identical application outcomes, admission counters, retries, actual feedback, transmission and ownership counters. The next milestone is the full portable regression gate and one unchanged 6,000-second campus run with continuous timing as the default. Nanosecond timing is not promoted.
