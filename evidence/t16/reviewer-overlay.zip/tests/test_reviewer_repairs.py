"""Synthetic integrity regressions; these do not execute or simulate MATLAB."""
from __future__ import annotations

import copy
import json
import math
from pathlib import Path
import tempfile
import unittest

import analyze_tranche11_return as references
import analyze_tranche16_return as gate


class ExplicitReferenceMembership(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="t16-reference-test-")
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.source = self.root / "source"
        self.source.mkdir()
        self.evidence = self.root / "evidence"
        self.evidence.mkdir()
        (self.source / "reference.bin").write_bytes(b"exact original reference")
        item = self.source / "reference.bin"
        self.inventory = [{"path": item.name, "sha256": references.sha256(item),
                           "bytes": item.stat().st_size}]
        self.snapshot = self.evidence / "references.json"
        self.snapshot.write_text(json.dumps(self.inventory))
        self.metadata = {"ReferenceFilesFinal": copy.deepcopy(self.inventory),
                         "ReferenceFilesStableDuringRun": True,
                         "ReferenceSnapshotSHA256": references.sha256(self.snapshot)}
        self.candidate = {"ReferenceRoots": [], "ReferenceFiles": [item.name]}

    def check(self):
        return references.verify_references(self.evidence, self.metadata,
                                             self.source, self.candidate)

    def test_rootless_explicit_exact_files_accepted(self):
        self.assertEqual(self.check()["count"], 1)

    def test_both_empty_still_rejected(self):
        self.candidate["ReferenceFiles"] = []
        with self.assertRaisesRegex(ValueError, "membership missing"):
            self.check()

    def test_nonlist_declaration_rejected(self):
        self.candidate["ReferenceRoots"] = ""
        with self.assertRaisesRegex(ValueError, "membership missing"):
            self.check()

    def test_duplicate_explicit_file_rejected(self):
        self.candidate["ReferenceFiles"] *= 2
        with self.assertRaisesRegex(ValueError, "Duplicate reference"):
            self.check()

    def test_undeclared_inventory_member_rejected(self):
        self.candidate["ReferenceFiles"] = ["other.bin"]
        with self.assertRaisesRegex(ValueError, "inventory differs"):
            self.check()

    def test_extra_declared_file_rejected(self):
        self.candidate["ReferenceFiles"].append("other.bin")
        with self.assertRaisesRegex(ValueError, "inventory differs"):
            self.check()

    def test_explicit_path_traversal_rejected(self):
        self.candidate["ReferenceFiles"] = ["../reference.bin"]
        with self.assertRaisesRegex(ValueError, "Unsafe"):
            self.check()

    def test_real_reference_hash_tamper_rejected(self):
        (self.source / "reference.bin").write_bytes(b"tampered reference data")
        with self.assertRaisesRegex(ValueError, "hash or size mismatch"):
            self.check()

    def test_reference_size_tamper_rejected_even_with_matching_snapshots(self):
        self.inventory[0]["bytes"] += 1
        self.snapshot.write_text(json.dumps(self.inventory))
        self.metadata["ReferenceFilesFinal"] = copy.deepcopy(self.inventory)
        self.metadata["ReferenceSnapshotSHA256"] = references.sha256(self.snapshot)
        with self.assertRaisesRegex(ValueError, "hash or size mismatch"):
            self.check()

    def test_changed_final_reference_inventory_rejected(self):
        self.metadata["ReferenceFilesFinal"][0]["sha256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "changed during run"):
            self.check()

    def test_missing_stability_flag_rejected(self):
        self.metadata["ReferenceFilesStableDuringRun"] = False
        with self.assertRaisesRegex(ValueError, "stability missing"):
            self.check()

    def test_reference_snapshot_hash_tamper_rejected(self):
        self.metadata["ReferenceSnapshotSHA256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "snapshot hash"):
            self.check()

    def test_root_expansion_still_supported(self):
        directory = self.source / "refs"
        directory.mkdir()
        (self.source / "reference.bin").rename(directory / "reference.bin")
        self.inventory[0]["path"] = "refs/reference.bin"
        self.snapshot.write_text(json.dumps(self.inventory))
        self.metadata["ReferenceFilesFinal"] = copy.deepcopy(self.inventory)
        self.metadata["ReferenceSnapshotSHA256"] = references.sha256(self.snapshot)
        self.candidate = {"ReferenceRoots": ["refs"], "ReferenceFiles": []}
        self.assertEqual(self.check()["count"], 1)
        self.candidate["ReferenceFiles"] = ["refs/reference.bin"]
        with self.assertRaisesRegex(ValueError, "Overlapping reference"):
            self.check()


class DeclaredBucketGrid(unittest.TestCase):
    def setUp(self):
        self.rows = [{"statistic": name, "time_s": str(index * 0.3), "value": "1"}
                     for name in gate.aggregate.CORE_SERIES for index in range(1, 6)]

    def check(self, left, right):
        return gate.bucket_differences(left, right, bucket_width_s=0.3, duration_s=1.5)

    def shifted(self, count):
        rows = copy.deepcopy(self.rows)
        value = float(rows[3]["time_s"])
        for _ in range(count):
            value = math.nextafter(value, math.inf)
        rows[3]["time_s"] = repr(value)
        return rows

    def test_serialization_roundoff_up_to_four_ulps_accepted(self):
        for count in range(5):
            with self.subTest(ulps=count):
                result = self.check(self.rows, self.shifted(count))
                self.assertTrue(all(item["max_abs_bucket_difference"] == 0 for item in result))

    def test_fifth_ulp_rejected(self):
        with self.assertRaisesRegex(ValueError, "off the declared bucket grid"):
            self.check(self.rows, self.shifted(5))

    def test_real_time_shift_rejected(self):
        rows = copy.deepcopy(self.rows)
        rows[3]["time_s"] = repr(float(rows[3]["time_s"]) + 1e-7)
        with self.assertRaisesRegex(ValueError, "off the declared bucket grid"):
            self.check(self.rows, rows)

    def test_matching_real_shifts_on_both_sides_rejected(self):
        rows = copy.deepcopy(self.rows)
        rows[3]["time_s"] = "1.200001"
        with self.assertRaisesRegex(ValueError, "off the declared bucket grid"):
            self.check(rows, copy.deepcopy(rows))

    def test_missing_bin_even_on_both_sides_rejected(self):
        with self.assertRaisesRegex(ValueError, "incomplete"):
            self.check(self.rows[:-1], self.rows[:-1])

    def test_missing_whole_series_rejected(self):
        rows = [r for r in self.rows if r["statistic"] != self.rows[0]["statistic"]]
        with self.assertRaisesRegex(ValueError, "incomplete"):
            self.check(rows, rows)

    def test_duplicate_identity_after_roundoff_normalization_rejected(self):
        rows = self.rows + [self.shifted(1)[3]]
        with self.assertRaisesRegex(ValueError, "Duplicate aggregate identity"):
            self.check(self.rows, rows)

    def test_shift_to_neighbor_bin_rejected_as_duplicate(self):
        rows = copy.deepcopy(self.rows)
        rows[3]["time_s"] = rows[4]["time_s"]
        with self.assertRaisesRegex(ValueError, "Duplicate aggregate identity"):
            self.check(self.rows, rows)

    def test_outside_declared_horizon_rejected(self):
        rows = copy.deepcopy(self.rows)
        rows[3]["time_s"] = "1.8"
        with self.assertRaisesRegex(ValueError, "off the declared bucket grid"):
            self.check(self.rows, rows)

    def test_zero_or_nonfinite_times_rejected(self):
        for value in ["0", "-1", "NaN", "inf"]:
            rows = copy.deepcopy(self.rows)
            rows[3]["time_s"] = value
            with self.subTest(time=value), self.assertRaises(ValueError):
                self.check(self.rows, rows)

    def test_nonintegral_declared_bin_count_rejected(self):
        with self.assertRaisesRegex(ValueError, "bucket count"):
            gate.bucket_differences(self.rows, self.rows, bucket_width_s=0.3, duration_s=1.55)

    def test_invalid_declared_width_or_duration_rejected(self):
        for width, duration in [(0, 1.5), (-0.3, 1.5), (0.3, 0), (0.3, -1.5),
                                (math.nan, 1.5), (0.3, math.inf), (None, 1.5)]:
            with self.subTest(width=width, duration=duration), self.assertRaises(ValueError):
                gate.bucket_differences(self.rows, self.rows, bucket_width_s=width, duration_s=duration)

    def test_actual_value_difference_preserved(self):
        rows = self.shifted(3)
        rows[3]["value"] = "9"
        result = self.check(self.rows, rows)
        self.assertEqual(result[0]["max_abs_bucket_difference"], 8)
        self.assertAlmostEqual(result[0]["mean_signed_bucket_difference"], 8 / 5)

    def test_missing_sample_remains_missing(self):
        left = copy.deepcopy(self.rows)
        left[3]["value"] = "NaN"
        right = self.shifted(2)
        result = self.check(left, right)
        self.assertEqual(result[0]["missing_sample_difference_count"], 1)
        self.assertEqual(result[0]["both_populated"], 4)

    def test_row_order_does_not_create_false_difference(self):
        result = self.check(self.rows, list(reversed(self.shifted(4))))
        self.assertTrue(all(item["max_abs_bucket_difference"] == 0 for item in result))


if __name__ == "__main__":
    unittest.main()
