#!/usr/bin/env python3
"""Run repair regressions and the issued T11/T16 reviewer tests with this overlay."""
from __future__ import annotations
import argparse
import importlib.util
import json
from pathlib import Path
import sys
import unittest

from run_review import ROOT, prepare_imports


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    prepare_imports()
    import analyze_tranche11_return
    import analyze_tranche16_return
    suite = unittest.TestSuite()
    paths = [ROOT / "tests/test_reviewer_repairs.py",
             args.source_root / "scripts/tests/test_tranche11_return.py",
             args.source_root / "scripts/tests/test_tranche16_return.py"]
    for index, path in enumerate(paths):
        spec = importlib.util.spec_from_file_location("review_tests_" + str(index), path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    args.output.write_text(json.dumps({"schema": "csr-t16-reviewer-tests-v1", "tests_run": result.testsRun,
        "failed": len(result.failures), "errors": len(result.errors), "skipped": len(result.skipped),
        "passed": result.wasSuccessful(), "matlab_executed": False,
        "test_modules": [str(path) for path in paths]}, indent=2) + "\n")
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
