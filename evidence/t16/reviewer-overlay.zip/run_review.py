#!/usr/bin/env python3
"""Apply the preserved reviewer overlay without changing the issued source tree."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent


def prepare_imports():
    manifest = json.loads((ROOT / "overlay-manifest.json").read_text())
    for row in manifest["files"]:
        path = ROOT / row["path"]
        if path.stat().st_size != row["bytes"] or hashlib.sha256(path.read_bytes()).hexdigest() != row["sha256"]:
            raise ValueError("Reviewer overlay manifest mismatch: " + row["path"])
    sys.path.insert(0, str(ROOT / "overlay"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    prepare_imports()
    import analyze_tranche16_return as gate
    return gate.main(["--source-root", str(args.source_root), "--evidence", str(args.evidence),
                      "--output", str(args.output)])


if __name__ == "__main__":
    raise SystemExit(main())
