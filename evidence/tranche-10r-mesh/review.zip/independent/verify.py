"""Independent read-only audit of returned mesh diagnostics and delivery ZIP."""
from collections import Counter
from datetime import datetime, timezone
from fnmatch import fnmatchcase
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import csv
import hashlib
import io
import json
import math
import re
import stat

BASE = Path('/workspace/scratch/1a5b1ad6ce1b')
OWNER = BASE / 'upload/mesh.zip'
DELIVERY = BASE / 'csr10r.zip'
OUT = BASE / 'm10_review/independent'
findings = []


def check(condition, message):
    if not condition:
        findings.append(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def rows(data):
    return list(csv.DictReader(io.StringIO(data.decode('utf-8-sig'), newline='')))


def archive_check(z):
    info = z.infolist()
    names = [entry.filename for entry in info]
    check(len(names) == len(set(names)), 'Duplicate ZIP member names')
    check(len(names) == len({name.casefold() for name in names}), 'Case-insensitive duplicate ZIP paths')
    for entry in info:
        name = entry.filename
        path = PurePosixPath(name)
        check(not path.is_absolute() and '..' not in path.parts and '.' not in path.parts
              and '\\' not in name and ':' not in name and '\x00' not in name,
              f'Unsafe ZIP path {name!r}')
        check(not stat.S_ISLNK(entry.external_attr >> 16), f'ZIP symlink {name}')
        check(not entry.flag_bits & 1, f'Encrypted ZIP member {name}')
    check(z.testzip() is None, 'ZIP CRC failure')
    return {
        'members': len(info),
        'regular_files': sum(not e.is_dir() for e in info),
        'expanded_bytes': sum(e.file_size for e in info),
        'longest_member_path': max(map(len, names)),
        'crc_verified': True,
    }


def expected_source_path(name):
    p = PurePosixPath(name)
    parts = p.parts
    if len(parts) == 1 and p.suffix == '.m':
        return True
    if parts[0] in ('+csr', 'tests', 'examples') and p.suffix == '.m':
        return True
    if parts[0] == 'scripts' and p.suffix in ('.py', '.cc', '.h'):
        return True
    if parts[0] in ('data', 'scenarios'):
        return True
    return len(parts) == 2 and parts[0] == 'evidence' and (
        fnmatchcase(parts[1], 'tranche-*-candidate.json') or parts[1] == 'source-baseline.json')


audit = {
    'schema': 'csr-tranche10-mesh-independent-return-audit-v1',
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'scope': 'Read-only owner evidence, inventory, exact source, tests, configuration, and scope labels.',
    'matlab_executed_by_reviewer': False,
    'owner_input': {'path': str(OWNER), 'sha256': sha(OWNER.read_bytes()), 'bytes': OWNER.stat().st_size},
    'immutable_delivery': {'path': str(DELIVERY), 'sha256': sha(DELIVERY.read_bytes()), 'bytes': DELIVERY.stat().st_size},
}

with ZipFile(OWNER) as z, ZipFile(DELIVERY) as package:
    audit['owner_zip'] = archive_check(z)
    audit['delivery_zip'] = archive_check(package)
    report = json.loads(z.read('report.json'))
    manifest = json.loads(z.read('raw/case_manifest.json'))
    source = json.loads(z.read('source.json'))
    config = json.loads(z.read('config.json'))
    state = json.loads(z.read('state.json'))
    summary = json.loads(z.read('raw/summary.json'))
    outer = report['Files']
    outer_paths = [entry['path'] for entry in outer]
    check(len(outer_paths) == len(set(outer_paths)), 'Duplicate outer inventory rows')
    check(set(z.namelist()) == set(outer_paths) | {'report.json'}, 'Outer inventory is not closed')
    for entry in outer:
        raw = z.read(entry['path'])
        check(sha(raw) == entry['sha256'], f"Outer SHA mismatch {entry['path']}")
        check(len(raw) == entry['bytes'], f"Outer size mismatch {entry['path']}")
    inner_paths = [entry['path'] for entry in manifest['files']]
    check(len(inner_paths) == len(set(inner_paths)), 'Duplicate inner inventory rows')
    actual_raw = {name[len('raw/'):] for name in z.namelist() if name.startswith('raw/')}
    check(actual_raw == set(inner_paths) | {'case_manifest.json'}, 'Inner inventory is not closed')
    inner_rows = {}
    for entry in manifest['files']:
        raw = z.read('raw/' + entry['path'])
        check(sha(raw) == entry['sha256'], f"Inner SHA mismatch {entry['path']}")
        check(len(raw) == entry['bytes'], f"Inner size mismatch {entry['path']}")
        if entry['row_count'] != []:
            observed = len(rows(raw))
            check(observed == entry['row_count'], f"CSV row count mismatch {entry['path']}")
            inner_rows[entry['path']] = observed
    local = report['LocalFiles']
    inner_local = manifest['local_files']
    check(local['path'] == 'raw/' + inner_local['path'], 'Local-only MAT path mismatch')
    check(local['sha256'] == inner_local['sha256'] and local['bytes'] == inner_local['bytes'], 'Local-only MAT record mismatch')
    check(local['path'] not in z.namelist(), 'Unexpected local-only MAT archive member')
    check(z.read('raw/protocol_trace.csv') == z.read('raw/trace.csv'), 'Protocol trace alias differs')
    audit['inventory'] = {
        'outer_closed_members': len(outer) + 1,
        'outer_sha_and_size_records_verified': len(outer),
        'inner_sha_and_size_records_verified': len(manifest['files']),
        'csv_row_counts_verified': len(inner_rows),
        'csv_rows': inner_rows,
        'local_only_mat': local,
        'local_mat_bytes_available': False,
        'protocol_trace_alias_identical': True,
    }

    expected_source = sorted(name for name in package.namelist() if not name.endswith('/') and expected_source_path(name))
    reported_source = [entry['path'] for entry in source]
    check(len(reported_source) == len(set(reported_source)), 'Duplicate source snapshot rows')
    check(reported_source == expected_source, 'Source snapshot path set/order differs from delivery sourceSnapshot rules')
    check(source == manifest['source_files'], 'Outer and inner source snapshots differ')
    check(sha(z.read('source.json')) == report['SourceSnapshotSHA256'], 'Source snapshot digest mismatch')
    source_matches = []
    for entry in source:
        raw = package.read(entry['path'])
        matched = sha(raw) == entry['sha256']
        check(matched, f"Source SHA mismatch against immutable delivery {entry['path']}")
        source_matches.append({'path': entry['path'], 'sha256': entry['sha256'], 'delivery_match': matched})
    audit['source'] = {
        'snapshot_paths_exact_to_delivery_selection': reported_source == expected_source,
        'source_rows': len(source),
        'matlab_source_rows': sum(entry['path'].endswith('.m') for entry in source),
        'all_bytes_match_delivery': all(entry['delivery_match'] for entry in source_matches),
        'snapshot_sha256': sha(z.read('source.json')),
        'matches': source_matches,
    }

    expected_test_names = []
    for cls in ('TestNeighbors', 'TestEventScheduler'):
        text = package.read('tests/' + cls + '.m').decode()
        methods = re.findall(r'^ {8}function\s+(\w+)\(', text, re.MULTILINE)
        expected_test_names.extend(cls + '/' + method for method in methods)
    tests = rows(z.read('tests.csv'))
    names = [test['Name'] for test in tests]
    check(names == expected_test_names, 'Executed test names/order do not exactly match delivered focused classes')
    check(len(tests) == 32 and len(tests) == len(set(names)), 'Incorrect or duplicate focused test count')
    for test in tests:
        check(test['Passed'] == '1' and test['Failed'] == '0' and test['Incomplete'] == '0', f"Nonpass focused test {test['Name']}")
        duration = float(test['DurationSeconds'])
        check(math.isfinite(duration) and duration >= 0, f"Invalid test duration {test['Name']}")
    check(report['TestCount'] == len(tests) and report['PassedTests'] == 32
          and report['FailedTests'] == 0 and report['IncompleteTests'] == 0,
          'Reported and actual focused test counts differ')
    audit['tests'] = {
        'expected_names_exact': names == expected_test_names,
        'class_counts': dict(Counter(n.split('/')[0] for n in names)),
        'passed': 32,
        'failed': 0,
        'incomplete': 0,
        'summed_test_duration_seconds': sum(float(t['DurationSeconds']) for t in tests),
        'actual_tests': tests,
    }

    for key in ('DurationSeconds', 'Seed', 'MaxEvents'):
        expected = {'DurationSeconds': 900, 'Seed': 128, 'MaxEvents': 2000000}[key]
        check(config[key] == expected and report[key] == expected, f'Changed mesh config {key}')
    check(state['MaxEvents'] == 2000000, 'Changed actual scheduler event cap')
    check(state['NowSeconds'] == 900 and state['NextEventSeconds'] > state['NowSeconds'], 'Mesh clock did not complete horizon')
    check(state['PendingEvents'] == 8, 'Unexpected final pending event count')
    check(config == summary['Config'], 'Config and result config differ')
    check(config['Name'] == 'research_mesh_6' and config['Backend'] == 'portable' and config['Stack'] == 'network', 'Incorrect mesh identity/backend')
    expected_positions = [[0,0,1],[3800,0,1],[7600,0,1],[0,3800,1],[3800,3800,1],[7600,3800,1]]
    check([node['Id'] for node in config['Nodes']] == list(range(1,7)), 'Unexpected mesh node IDs')
    check([node['PositionMeters'] for node in config['Nodes']] == expected_positions, 'Mesh geometry differs from canonical factory')
    check([flow['SourceId'] for flow in config['Traffic']] == [4,5,6], 'Wrong flow sources')
    for i, flow in enumerate(config['Traffic']):
        for key, value in {'DestinationId':1,'StartSeconds':360+6*i,'IntervalSeconds':36,
                           'PacketCount':5,'ApplicationPayloadBytes':64,'Dscp':8*i,'AckRequired':True}.items():
            check(flow[key] == value, f'Incorrect traffic stimulus {i+1}/{key}')
    check(config['Channel']['Model'] == 'csr-phy' and config['Channel']['FixedDropProbability'] == 0, 'Wrong mesh PHY channel')
    check(config['Research']['ImportedHistoricalCampus'] is False, 'Mesh incorrectly claims historical campus fixture')
    check(config['LinkEvents'] == [] and config['Faults'] == [], 'Mesh has added stimuli or injected faults')
    check(report['DiagnosticOnly'] is True and report['FullAcceptanceGateExecuted'] is False
          and report['NumericalParityEstablished'] is False and manifest['numerical_parity_established'] is False,
          'Incorrect diagnostic/acceptance/parity scope labels')
    check(report['Status'] == 'completed' and report['MATLABExecuted'] is True
          and report['TestsExecuted'] is True and report['TestsPassed'] is True
          and report['MeshStarted'] is True and report['MeshCompleted'] is True
          and report['SourceFilesStableDuringRun'] is True, 'Incomplete run flags')
    check(report['MATLABVersion'] == manifest['matlab_version'] == summary['Metadata']['Version'], 'MATLAB version mismatch')
    check(report['MATLABRelease'] == manifest['matlab_release'] == summary['Metadata']['Release'] == '2025a', 'MATLAB release mismatch')
    audit['run'] = {
        'owner_matlab_version': report['MATLABVersion'],
        'duration_seconds': config['DurationSeconds'],
        'seed': config['Seed'],
        'max_events': state['MaxEvents'],
        'final_now_seconds': state['NowSeconds'],
        'next_event_seconds': state['NextEventSeconds'],
        'pending_events': state['PendingEvents'],
        'runtime_seconds': report['RuntimeSeconds'],
        'completed': report['Status'] == 'completed',
        'diagnostic_only': True,
        'full_tranche10_acceptance_established': False,
        'numerical_parity_established': False,
    }

audit['blockers'] = findings
audit['passed'] = not findings
audit['limitations'] = [
    'This audit verifies returned files and their recorded execution; it performs no MATLAB execution.',
    'The local-only results.mat was deliberately excluded by the delivered exporter; its bytes cannot be audited from this archive.',
    'A successful focused mesh does not establish full Tranche 10 acceptance or campus/ns-3 numerical parity.',
    'The original failure lacks callback/clock evidence; this return does not retrospectively prove the precise callback that exhausted its event cap.',
]
OUT.mkdir(parents=True, exist_ok=True)
(OUT / 'audit.json').write_text(json.dumps(audit, indent=2) + '\n')
md = f'''# Independent mesh return audit

Result: {'PASS' if audit['passed'] else 'BLOCKED'}; {len(findings)} blocker(s).

The returned `mesh.zip` is a safe, CRC-valid, closed 20-member archive. All 19 outer and 13 inner hash/size records verify, along with all 12 CSV row counts. The local-only MAT result is explicitly excluded by the delivered exporter.

The source snapshot selects and matches all {len(source)} delivered files ({audit['source']['matlab_source_rows']} MATLAB files) exactly against immutable `csr10r.zip`; the inner and outer snapshots agree. All 32 actual test names match the delivered classes exactly (25 neighbor tests, 7 scheduler tests), and all report Passed=1, Failed=0, Incomplete=0.

The owner ran MATLAB {report['MATLABVersion']}. The canonical six-node mesh used seed 128, 900 simulated seconds, and the original 2,000,000-event limit. Its clock reached 900 s, with eight future events and next event 900.0680000000219 s. Recorded simulation runtime was {report['RuntimeSeconds']} s. Configuration and result copies agree.

This accepts the returned evidence as a successful focused diagnostic. It does not establish full Tranche 10 acceptance, campus completion, or numerical parity; the archive accurately labels these limits. The previous run did not record its exhausted callback, so the return supports repair effectiveness on this fixture without proving the previous failing callback retroactively.

Owner ZIP SHA-256: `{audit['owner_input']['sha256']}`.

Delivery ZIP SHA-256: `{audit['immutable_delivery']['sha256']}`.

No source or input archive was edited, and the reviewer did not run MATLAB.
'''
if findings:
    md += '\nBlockers:\n\n' + '\n'.join('- ' + finding for finding in findings) + '\n'
(OUT / 'audit.md').write_text(md)
print(json.dumps({key: value for key, value in audit.items() if key not in ('source', 'tests')}, indent=2))
