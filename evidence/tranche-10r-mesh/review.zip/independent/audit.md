# Independent mesh return audit

Result: PASS; 0 blocker(s).

The returned `mesh.zip` is a safe, CRC-valid, closed 20-member archive. All 19 outer and 13 inner hash/size records verify, along with all 12 CSV row counts. The local-only MAT result is explicitly excluded by the delivered exporter.

The source snapshot selects and matches all 225 delivered files (124 MATLAB files) exactly against immutable `csr10r.zip`; the inner and outer snapshots agree. All 32 actual test names match the delivered classes exactly (25 neighbor tests, 7 scheduler tests), and all report Passed=1, Failed=0, Incomplete=0.

The owner ran MATLAB 25.1.0.2943329 (R2025a). The canonical six-node mesh used seed 128, 900 simulated seconds, and the original 2,000,000-event limit. Its clock reached 900 s, with eight future events and next event 900.0680000000219 s. Recorded simulation runtime was 125.3328103 s. Configuration and result copies agree.

This accepts the returned evidence as a successful focused diagnostic. It does not establish full Tranche 10 acceptance, campus completion, or numerical parity; the archive accurately labels these limits. The previous run did not record its exhausted callback, so the return supports repair effectiveness on this fixture without proving the previous failing callback retroactively.

Owner ZIP SHA-256: `553559bd4baaaad56ef36be18d34b084f28e2eb5e2b4b56cd11c98c610d10a34`.

Delivery ZIP SHA-256: `df3ad517708fccc9e4c85d8e38c3492b97aff8d2d5236b3f05249da3cd15b900`.

No source or input archive was edited, and the reviewer did not run MATLAB.
