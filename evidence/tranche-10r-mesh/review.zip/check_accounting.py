"""Read-only accounting review of the returned Tranche 10 mesh diagnostic.

Run from the workspace: python m10_review/check_accounting.py
No MATLAB execution; only archived owner outputs are analyzed.
"""
from collections import Counter
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import zipfile

WORK = Path(__file__).resolve().parents[1]
OWNER = WORK / 'upload/mesh.zip'
BASE = WORK / 'csr10/evidence/tranche-7-r2025a-accepted/tranche7_evidence.zip'


def rows(bundle, name):
    return list(csv.DictReader(io.StringIO(bundle.read(name).decode('utf-8-sig'))))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify():
    checks = []

    def require(value, label):
        if not value:
            raise AssertionError(label)
        checks.append(label)

    with zipfile.ZipFile(OWNER) as z:
        report = json.loads(z.read('report.json'))
        summary = json.loads(z.read('raw/summary.json'))
        config = json.loads(z.read('config.json'))
        stats = report['Statistics']
        state = json.loads(z.read('state.json'))
        research = rows(z, 'raw/research_summary.csv')[0]
        protocol = rows(z, 'raw/protocol_trace.csv')
        phy = rows(z, 'raw/phy_trace.csv')
        nodes = rows(z, 'raw/nodes.csv')
        hops = rows(z, 'raw/hop_nodes.csv')
        networks = rows(z, 'raw/nwk_nodes.csv')

    require(stats == summary['Statistics'], 'Wrapper and raw statistics agree')
    require(config == summary['Config'], 'Wrapper and raw configuration agree')
    require(summary['Metadata']['Release'] == report['MATLABRelease'] == '2025a', 'Owner release agrees')
    require(summary['Metadata']['RuntimeSeconds'] == report['RuntimeSeconds'], 'Owner runtime agrees')
    require(stats['Generated'] == stats['Received'] + stats['Dropped'] + stats['Pending'], 'Application balance')
    require(stats['PhysicalAttempts'] == stats['PhysicalReceived'] + stats['PhysicalDropped'] + stats['PhysicalPending'],
            'Receiver-observation balance')
    for field in ['Generated', 'Received', 'Dropped']:
        require(sum(int(r[field]) for r in nodes) == stats[field], 'Node total: ' + field)
    for field in ['OmittedTraceRecords', 'OmittedPhyTraceRecords', 'OmittedApplicationAdmissionRecords']:
        require(stats[field] == 0, 'Complete trace: ' + field)
    for label, data in [('protocol', protocol), ('PHY', phy)]:
        times = [float(r['TimeSeconds']) for r in data]
        require(all(math.isfinite(t) and 0 <= t <= config['DurationSeconds'] for t in times), label + ' time range')
        require(all(a <= b for a, b in zip(times, times[1:])), label + ' chronological order')

    generated = {int(r['PacketId']): r for r in protocol if r['Event'] == 'app_generate'}
    delivered = {int(r['PacketId']): r for r in protocol if r['Event'] == 'app_receive'}
    require(len(generated) == stats['Generated'] == 15, 'Unique generated application identities')
    require(len(delivered) == stats['Received'] == 15, 'Unique delivered application identities')
    require(sum(r['Event'] == 'app_generate' for r in protocol) == len(generated), 'No duplicate generation')
    require(sum(r['Event'] == 'app_receive' for r in protocol) == len(delivered), 'No duplicate delivery')
    require(generated.keys() == delivered.keys(), 'All generated applications have a delivery')
    expected = Counter()
    for flow in config['Traffic']:
        for ordinal in range(flow['PacketCount']):
            time = flow['StartSeconds'] + ordinal * flow['IntervalSeconds']
            if time <= config['DurationSeconds']:
                expected[(flow['SourceId'], flow['DestinationId'], time,
                          flow['ApplicationPayloadBytes'], flow['Dscp'])] += 1
    observed = Counter((int(r['NodeId']), int(r['PeerId']), float(r['TimeSeconds']),
                        int(r['ApplicationBytes']), int(r['Dscp'])) for r in generated.values())
    require(observed == expected, 'Exact configured source/destination/timing/payload/DSCP schedule')
    applications = []
    for packet, sent in generated.items():
        received = delivered[packet]
        require(int(received['NodeId']) == int(sent['PeerId']) and
                int(received['ApplicationBytes']) == int(sent['ApplicationBytes']),
                'Delivery endpoint and bytes: ' + str(packet))
        latency = float(received['TimeSeconds']) - float(sent['TimeSeconds'])
        require(latency >= 0, 'Nonnegative application latency: ' + str(packet))
        applications.append({'packet_id': packet, 'source_id': int(sent['NodeId']),
                             'destination_id': int(received['NodeId']), 'bytes': int(sent['ApplicationBytes']),
                             'generated_seconds': float(sent['TimeSeconds']), 'latency_seconds': latency})
    require(sum(a['bytes'] for a in applications) == stats['ApplicationBytesReceived'] == 960, 'Delivered byte total')
    require(math.isclose(sum(a['latency_seconds'] for a in applications), stats['LatencySumSeconds'], abs_tol=1e-8),
            'Latency sum reconstructed from trace')
    require(math.isclose(stats['LatencySumSeconds'] / len(applications), stats['MeanLatencySeconds'], abs_tol=1e-10),
            'Mean latency reconstructed')

    event_counts = Counter(r['Event'] for r in protocol)
    require(event_counts['tx_start'] == stats['PhysicalTransmissions'], 'OTA transmission count reconstructed')
    require(stats['PhysicalAttempts'] == stats['PhysicalTransmissions'] * (len(config['Nodes']) - 1),
            'One observation per non-sender receiver')
    ends = [r for r in phy if r['Event'] == 'phy_signal_end']
    require(len(ends) == stats['PhysicalAttempts'], 'All receiver observations have end records')
    require(sum(int(r['Success']) for r in ends) == stats['PhysicalReceived'], 'Successful receiver observations')
    reasons = Counter(r['Reason'] for r in ends if not int(r['Success']))
    require(dict(reasons) == stats['PhysicalDropReasons'], 'Physical failure reasons reconstructed')
    require(stats['Retransmissions'] == sum(int(r['Retransmissions']) for r in hops) == 0, 'No DATA retransmissions')
    require(event_counts['hop_ack'] == stats['AcksReceived'] == 30, 'DATA hop acknowledgments reconstructed')
    for field in ['PendingData', 'ResendQueueDepth', 'DackHoldCount', 'ControlPending', 'ControlPendingTargets']:
        require(sum(int(r[field]) for r in hops) == 0, 'Drained HOP ownership: ' + field)
    for field in ['PendingCustody', 'PendingControlMessages', 'WaitingForHop', 'WaitingForRoute']:
        require(sum(int(r[field]) for r in networks) == 0, 'Drained NWK ownership: ' + field)
    require(research['DataDrained'] == research['StructuralChecksPassed'] == '1', 'Research flags agree with reconstructed state')
    require(state['NowSeconds'] == config['DurationSeconds'] == 900 and state['NextEventSeconds'] > 900,
            'Simulation reaches horizon with next callback strictly later')
    require(state['PendingEvents'] == summary['Metadata']['PendingEvents'] == 8, 'Final pending event count agrees')

    require(digest(BASE) == 'ea39b86ef68f91a551e4e22d176e2e96dc5305f33673741eee0adc6039599655',
            'Accepted T7 baseline archive hash')
    with zipfile.ZipFile(BASE) as old_zip:
        paths = [n for n in old_zip.namelist() if n.endswith('/research/mesh_6_seed_128/summary.json')]
        require(len(paths) == 1, 'Unique accepted T7 mesh')
        baseline = json.loads(old_zip.read(paths[0]))
    require(config == baseline['Config'], 'Complete mesh configuration identical to accepted T7')
    before = baseline['Statistics']
    result = {'schema': 'csr-tranche10r-mesh-accounting-review-v1', 'status': 'passed',
              'owner_archive_sha256': digest(OWNER), 'checks_passed': len(checks), 'checks': checks,
              'matlab_executed_by_reviewer': False, 'owner_matlab_release': report['MATLABRelease'],
              'owner_version': report['MATLABVersion'], 'owner_runtime_seconds': report['RuntimeSeconds'],
              'duration_seconds': 900, 'seed': 128, 'max_events': 2000000,
              'protocol_rows': len(protocol), 'phy_rows': len(phy),
              'statistics': stats, 'applications': applications,
              'pending_scheduler_events': 8, 'next_event_seconds': state['NextEventSeconds'],
              'pending_scheduler_scope': 'Future callbacks after the finite horizon; application, HOP and NWK custody queues are empty.',
              'control_retry_events': event_counts['hop_retry'],
              'control_failure_events': event_counts['hop_control_failed'],
              't7_comparison': {'identical_complete_config': True,
                                'generated': [before['Generated'], stats['Generated']],
                                'received': [before['Received'], stats['Received']],
                                'mean_latency_seconds': [before['MeanLatencySeconds'], stats['MeanLatencySeconds']],
                                'ota_transmissions': [before['PhysicalTransmissions'], stats['PhysicalTransmissions']],
                                'interpretation': 'Descriptive single-seed comparison across T7 and repaired T10; does not isolate the retry repair or prove ns-3 parity.'},
              'full_tranche10_acceptance': False, 'numerical_parity_established': False,
              'next_step': 'Run the unchanged full run_tranche10_validation from the same csr10r package.'}
    (Path(__file__).parent / 'accounting.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks_passed', 'protocol_rows', 'phy_rows', 't7_comparison']}))


if __name__ == '__main__':
    verify()
